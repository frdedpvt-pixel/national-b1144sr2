/**
 * MHIL - Micro-Health Intelligence Layer
 * Main JavaScript Application
 */

const API_BASE = '';

// State management
const state = {
    wards: [],
    currentWard: null,
    loading: false,
    view: 'dashboard' // dashboard, ward, simulation, citizen
};

// Utility functions
const formatPercent = (value) => `${(value * 100).toFixed(1)}%`;
const formatNumber = (num) => num?.toLocaleString() || 'N/A';

const getRiskClass = (priority) => {
    const map = { 'CRITICAL': 'critical', 'HIGH': 'high', 'MEDIUM': 'medium', 'LOW': 'low' };
    return map[priority] || 'medium';
};

const getRiskColor = (priority) => {
    const map = { 'CRITICAL': '#dc2626', 'HIGH': '#ef4444', 'MEDIUM': '#f59e0b', 'LOW': '#10b981' };
    return map[priority] || '#64748b';
};

// API calls
async function apiCall(endpoint, options = {}) {
    try {
        const response = await fetch(`${API_BASE}${endpoint}`, {
            headers: { 'Content-Type': 'application/json' },
            ...options
        });
        if (!response.ok) throw new Error(`API Error: ${response.status}`);
        return await response.json();
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

// Data fetching
async function fetchWards() {
    const data = await apiCall('/api/wards');
    state.wards = data.wards;
    return data;
}

async function fetchWardDetail(wardId) {
    return await apiCall(`/api/wards/${wardId}`);
}

async function fetchPrioritization() {
    return await apiCall('/api/risk/prioritization');
}

async function fetchRecommendations() {
    return await apiCall('/api/decisions/recommendations');
}

async function simulateIntervention(wardId, intervention, intensity) {
    return await apiCall('/api/simulation/whatif', {
        method: 'POST',
        body: JSON.stringify({ ward_id: wardId, intervention, intensity_percent: intensity })
    });
}

async function simulateDelay(wardId, days) {
    return await apiCall('/api/simulation/delay', {
        method: 'POST',
        body: JSON.stringify({ ward_id: wardId, delay_days: days })
    });
}

async function submitCitizenReport(report) {
    return await apiCall('/api/citizen/report', {
        method: 'POST',
        body: JSON.stringify(report)
    });
}

async function allocateResources(resourceType, units) {
    return await apiCall('/api/resources/allocate', {
        method: 'POST',
        body: JSON.stringify({ resource_type: resourceType, available_units: units })
    });
}

async function generatePolicyBrief(wardId) {
    return await apiCall(`/api/wards/${wardId}/policy-brief`);
}

// Rendering functions
function renderDashboard(data) {
    const container = document.getElementById('main-content');
    
    container.innerHTML = `
        <!-- Stats Overview -->
        <div class="section">
            <div class="grid grid-cols-4 gap-4">
                <div class="stat-card">
                    <span class="stat-label">Total Wards</span>
                    <span class="stat-value">${data.total_wards}</span>
                </div>
                <div class="stat-card">
                    <span class="stat-label">High Risk Wards</span>
                    <span class="stat-value critical">${data.high_risk_count}</span>
                    <span class="stat-change up">⚠️ Requires immediate attention</span>
                </div>
                <div class="stat-card">
                    <span class="stat-label">Medium Risk</span>
                    <span class="stat-value medium">${data.medium_risk_count}</span>
                </div>
                <div class="stat-card">
                    <span class="stat-label">Low Risk</span>
                    <span class="stat-value low">${data.low_risk_count}</span>
                </div>
            </div>
        </div>

        <!-- Priority Alerts -->
        ${data.high_risk_count > 0 ? `
        <div class="section">
            <div class="alert alert-danger">
                <span>🚨</span>
                <div>
                    <strong>Immediate Action Required:</strong> ${data.high_risk_count} ward(s) are at CRITICAL/HIGH risk level.
                    Click on a ward below to view detailed recommendations.
                </div>
            </div>
        </div>
        ` : ''}

        <!-- Ward Grid -->
        <div class="section">
            <div class="section-header">
                <h2 class="section-title">📍 Ward Overview</h2>
                <div class="flex gap-2">
                    <button class="btn btn-secondary btn-sm" onclick="showPrioritization()">
                        📊 Prioritization Table
                    </button>
                    <button class="btn btn-secondary btn-sm" onclick="showResourceAllocation()">
                        🔧 Resource Advisor
                    </button>
                </div>
            </div>
            <div class="ward-grid" id="ward-grid">
                ${data.wards.map(ward => renderWardCard(ward)).join('')}
            </div>
        </div>
    `;
}

function renderWardCard(ward) {
    const riskClass = getRiskClass(ward.priority);
    const trendIcon = ward.trend === 'increasing' ? '↑' : ward.trend === 'decreasing' ? '↓' : '→';
    
    return `
        <div class="ward-card ${riskClass}" onclick="viewWard(${ward.ward_id})">
            <div class="ward-header">
                <div>
                    <div class="ward-name">${ward.name}</div>
                    <div class="ward-id">Ward #${ward.ward_id}</div>
                </div>
                <div class="ward-risk">
                    <span class="risk-score" style="color: ${getRiskColor(ward.priority)}">
                        ${formatPercent(ward.risk_score)}
                    </span>
                    <span class="risk-label ${riskClass}">${ward.priority}</span>
                </div>
            </div>
            <div class="ward-stats">
                <div class="ward-stat">
                    <span class="ward-stat-value">${formatNumber(ward.population)}</span>
                    <span class="ward-stat-label">Population</span>
                </div>
                <div class="ward-stat">
                    <span class="ward-stat-value">${ward.vulnerability}</span>
                    <span class="ward-stat-label">Vulnerability</span>
                </div>
                <div class="ward-stat">
                    <span class="ward-stat-value">${trendIcon} ${ward.trend}</span>
                    <span class="ward-stat-label">Trend</span>
                </div>
            </div>
            ${ward.anomaly_warning !== 'GREEN' ? `
                <div class="mt-2">
                    <span class="badge badge-${ward.anomaly_warning === 'RED' ? 'critical' : ward.anomaly_warning === 'ORANGE' ? 'high' : 'medium'}">
                        ⚡ ${ward.anomaly_warning} Alert
                    </span>
                </div>
            ` : ''}
        </div>
    `;
}

async function viewWard(wardId) {
    showLoading();
    try {
        const data = await fetchWardDetail(wardId);
        state.currentWard = data;
        renderWardDetail(data);
    } catch (error) {
        showError('Failed to load ward details');
    }
    hideLoading();
}

function renderWardDetail(data) {
    const container = document.getElementById('main-content');
    const riskClass = getRiskClass(data.composite_risk.priority);
    
    container.innerHTML = `
        <div class="section">
            <button class="btn btn-secondary mb-4" onclick="loadDashboard()">
                ← Back to Dashboard
            </button>
            
            <!-- Ward Header -->
            <div class="card mb-4">
                <div class="flex justify-between items-center">
                    <div>
                        <h1>${data.ward_name}</h1>
                        <p class="text-muted">Ward #${data.ward_id} | Population: ${formatNumber(data.ward_data.population)}</p>
                    </div>
                    <div class="text-right">
                        <div class="text-xs text-muted mb-1">Composite Risk Score</div>
                        <div class="stat-value ${riskClass}">${formatPercent(data.composite_risk.composite_score)}</div>
                        <span class="badge badge-${riskClass}">${data.composite_risk.priority}</span>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-2 gap-4 mb-4">
                <!-- Risk Prediction Panel -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">🎯 Risk Prediction</h3>
                        <span class="badge badge-info">ML: Random Forest</span>
                    </div>
                    <div class="flex justify-between items-center mb-4">
                        <div>
                            <div class="text-xs text-muted">Outbreak Probability</div>
                            <div class="text-2xl font-bold">${formatPercent(data.risk_prediction.risk_probability)}</div>
                        </div>
                        <div>
                            <div class="text-xs text-muted">Confidence</div>
                            <div class="text-xl font-bold">${formatPercent(data.risk_prediction.confidence)}</div>
                        </div>
                    </div>
                    <div class="progress-bar mb-2">
                        <div class="progress-fill ${riskClass}" style="width: ${data.risk_prediction.risk_probability * 100}%"></div>
                    </div>
                </div>

                <!-- Time to Outbreak -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">⏱️ Time-to-Outbreak Estimate</h3>
                    </div>
                    <div class="text-center">
                        <div class="stat-value ${data.time_to_outbreak.estimated_days <= 5 ? 'critical' : 'medium'}">
                            ${data.time_to_outbreak.estimated_days} days
                        </div>
                        <div class="text-sm text-muted mb-2">Range: ${data.time_to_outbreak.range}</div>
                        <span class="badge badge-${data.time_to_outbreak.confidence === 'HIGH' ? 'high' : 'medium'}">
                            ${data.time_to_outbreak.confidence} Confidence
                        </span>
                        <p class="text-xs text-muted mt-2">${data.time_to_outbreak.basis}</p>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-2 gap-4 mb-4">
                <!-- Health Indicators -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">🏥 Health Indicators</h3>
                    </div>
                    <table>
                        <tr><td class="text-muted">Weekly Fever Cases</td><td class="text-right font-bold">${data.ward_data.fever_weekly}</td></tr>
                        <tr><td class="text-muted">Dengue Cases</td><td class="text-right font-bold">${data.ward_data.dengue_cases}</td></tr>
                        <tr><td class="text-muted">Waterborne Cases</td><td class="text-right font-bold">${data.ward_data.waterborne_cases}</td></tr>
                        <tr><td class="text-muted">Respiratory Cases</td><td class="text-right font-bold">${data.ward_data.respiratory_cases}</td></tr>
                        <tr><td class="text-muted">5-Year Trend</td><td class="text-right font-bold">${data.ward_data.trend_5yr}</td></tr>
                    </table>
                </div>

                <!-- Environmental Indicators -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">🌍 Environmental Indicators</h3>
                    </div>
                    <table>
                        <tr><td class="text-muted">Air Quality Index (AQI)</td><td class="text-right font-bold">${data.ward_data.aqi}</td></tr>
                        <tr><td class="text-muted">Rainfall (mm)</td><td class="text-right font-bold">${data.ward_data.rainfall_mm}</td></tr>
                        <tr><td class="text-muted">Garbage Backlog</td><td class="text-right font-bold">${formatPercent(data.ward_data.garbage_backlog_idx)}</td></tr>
                        <tr><td class="text-muted">Water Stagnation</td><td class="text-right font-bold">${formatPercent(data.ward_data.water_stagnation_idx)}</td></tr>
                        <tr><td class="text-muted">Water Quality</td><td class="text-right font-bold">${formatPercent(data.ward_data.water_quality_idx)}</td></tr>
                    </table>
                </div>
            </div>

            <!-- Explainable AI Panel -->
            <div class="card mb-4">
                <div class="card-header">
                    <h3 class="card-title">🧠 Explainable AI - Root Cause Analysis</h3>
                    <span class="badge badge-info">Data Quality: ${data.root_cause_analysis.data_quality.quality_score}</span>
                </div>
                <p class="mb-4">${data.root_cause_analysis.text_explanation}</p>
                <h4 class="mb-2 text-sm">Feature Contribution Breakdown:</h4>
                ${renderFeatureContributions(data.risk_prediction.feature_contributions)}
            </div>

            <!-- Recommendations Panel -->
            <div class="card mb-4">
                <div class="card-header">
                    <h3 class="card-title">📋 Action Recommendations</h3>
                    <button class="btn btn-primary btn-sm" onclick="showPolicyBrief(${data.ward_id})">
                        📄 Generate Policy Brief
                    </button>
                </div>
                ${data.recommendations.map((rec, i) => `
                    <div class="alert alert-${rec.urgency === 'IMMEDIATE' ? 'danger' : rec.urgency === 'WITHIN_24H' ? 'warning' : 'info'} mb-2">
                        <span>${i + 1}.</span>
                        <div>
                            <strong>${rec.action_name}</strong>
                            <span class="badge badge-${rec.urgency === 'IMMEDIATE' ? 'critical' : rec.urgency === 'WITHIN_24H' ? 'high' : 'medium'} ml-2">
                                ${rec.urgency.replace('_', ' ')}
                            </span>
                            <p class="text-sm mt-1">${rec.reason_for_action}</p>
                            <div class="text-xs text-muted mt-1">
                                Cost: ${rec.cost_level} | Impact: ${rec.impact_level} | Time to Effect: ${rec.time_to_effect_days} days
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>

            <!-- What-If Simulation -->
            <div class="card mb-4">
                <div class="card-header">
                    <h3 class="card-title">🔮 What-If Simulation</h3>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <h4 class="text-sm mb-2">Simulate Intervention</h4>
                        <div class="form-group mb-3">
                            <label class="form-label">Intervention Type</label>
                            <select class="form-select" id="sim-intervention">
                                <option value="sanitation_improvement">Sanitation Improvement</option>
                                <option value="fogging_operation">Fogging Operation</option>
                                <option value="medical_camp_deployment">Medical Camp</option>
                                <option value="water_treatment">Water Treatment</option>
                            </select>
                        </div>
                        <div class="form-group mb-3">
                            <label class="form-label">Intensity: <span id="intensity-value">50</span>%</label>
                            <input type="range" class="range-slider" id="sim-intensity" min="10" max="100" value="50"
                                oninput="document.getElementById('intensity-value').textContent = this.value">
                        </div>
                        <button class="btn btn-primary" onclick="runIntervention(${data.ward_id})">
                            Run Simulation
                        </button>
                    </div>
                    <div>
                        <h4 class="text-sm mb-2">Simulate Delay</h4>
                        <div class="form-group mb-3">
                            <label class="form-label">Delay Period (days)</label>
                            <select class="form-select" id="sim-delay-days">
                                <option value="3">3 days</option>
                                <option value="7">7 days</option>
                                <option value="14">14 days</option>
                            </select>
                        </div>
                        <button class="btn btn-danger" onclick="runDelaySimulation(${data.ward_id})">
                            Simulate Delay
                        </button>
                    </div>
                </div>
                <div id="simulation-result" class="mt-4"></div>
            </div>

            <!-- Anomaly Detection -->
            ${data.anomaly_detection.warning_level !== 'GREEN' ? `
            <div class="card mb-4">
                <div class="card-header">
                    <h3 class="card-title">⚡ Anomaly Detection Alert</h3>
                    <span class="badge badge-${data.anomaly_detection.warning_level === 'RED' ? 'critical' : 'high'}">
                        ${data.anomaly_detection.warning_level}
                    </span>
                </div>
                <p class="mb-2">${data.anomaly_detection.early_warning}</p>
                ${data.anomaly_detection.spikes_detected.length > 0 ? `
                    <h4 class="text-sm mt-3 mb-2">Detected Spikes:</h4>
                    ${data.anomaly_detection.spikes_detected.map(spike => `
                        <div class="alert alert-warning mb-1">
                            <strong>${spike.indicator}:</strong>
                            Current: ${spike.current_value} | Expected: ${spike.expected_value} |
                            Deviation: ${spike.deviation}
                        </div>
                    `).join('')}
                ` : ''}
            </div>
            ` : ''}
        </div>
    `;
}

function renderFeatureContributions(contributions) {
    const sorted = Object.entries(contributions).sort((a, b) => b[1] - a[1]);
    
    return sorted.map(([feature, value]) => `
        <div class="factor-bar">
            <span class="factor-label">${formatFeatureName(feature)}</span>
            <div class="factor-bar-container">
                <div class="factor-bar-fill" style="width: ${Math.min(value * 3, 100)}%"></div>
            </div>
            <span class="factor-value">${value.toFixed(1)}%</span>
        </div>
    `).join('');
}

function formatFeatureName(name) {
    const map = {
        'fever_weekly': 'Weekly Fever Cases',
        'dengue_cases': 'Dengue Cases',
        'waterborne_cases': 'Waterborne Cases',
        'respiratory_cases': 'Respiratory Cases',
        'aqi': 'Air Quality Index',
        'garbage_backlog_idx': 'Garbage Backlog',
        'water_stagnation_idx': 'Water Stagnation',
        'water_quality_idx': 'Water Quality',
        'population_density': 'Population Density',
        'hospital_capacity_score': 'Healthcare Capacity',
        'citizen_reports_count': 'Citizen Reports'
    };
    return map[name] || name;
}

async function runIntervention(wardId) {
    const intervention = document.getElementById('sim-intervention').value;
    const intensity = parseInt(document.getElementById('sim-intensity').value);
    
    showLoading();
    try {
        const result = await simulateIntervention(wardId, intervention, intensity);
        document.getElementById('simulation-result').innerHTML = `
            <div class="alert alert-success">
                <div>
                    <strong>Simulation Result: ${result.intervention}</strong>
                    <p class="mt-2">
                        Original Risk: <strong>${formatPercent(result.original_risk)}</strong> →
                        Simulated Risk: <strong>${formatPercent(result.simulated_risk)}</strong>
                    </p>
                    <p class="text-sm">
                        Risk Change: <span class="font-bold" style="color: #10b981">${result.risk_change_percent}</span>
                        | Effectiveness: ${result.effectiveness}
                        | Time to Effect: ${result.time_to_effect_days} days
                    </p>
                </div>
            </div>
        `;
    } catch (error) {
        showError('Simulation failed');
    }
    hideLoading();
}

async function runDelaySimulation(wardId) {
    const days = parseInt(document.getElementById('sim-delay-days').value);
    
    showLoading();
    try {
        const result = await simulateDelay(wardId, days);
        document.getElementById('simulation-result').innerHTML = `
            <div class="alert alert-danger">
                <div>
                    <strong>Delay Simulation: ${days} days</strong>
                    <p class="mt-2">
                        Current Risk: <strong>${formatPercent(result.original_risk)}</strong> →
                        Projected Risk: <strong>${formatPercent(result.projected_risk)}</strong>
                    </p>
                    <p class="text-sm">
                        Risk Increase: <span class="font-bold" style="color: #ef4444">${result.risk_increase_percent}</span>
                        | Consequence: ${result.consequence_level}
                    </p>
                    <p class="mt-2 text-sm">${result.recommendation}</p>
                </div>
            </div>
        `;
    } catch (error) {
        showError('Simulation failed');
    }
    hideLoading();
}

async function showPolicyBrief(wardId) {
    showLoading();
    try {
        const result = await generatePolicyBrief(wardId);
        showModal('Policy Brief - ' + result.ward_name, `
            <pre style="white-space: pre-wrap; font-family: monospace; font-size: 0.8rem; background: var(--bg-tertiary); padding: 1rem; border-radius: 8px; max-height: 400px; overflow-y: auto;">
${result.policy_brief}
            </pre>
            <div class="mt-4 text-sm text-muted">
                Generated: ${new Date(result.generated_at).toLocaleString()}
            </div>
        `);
    } catch (error) {
        showError('Failed to generate policy brief');
    }
    hideLoading();
}

async function showPrioritization() {
    showLoading();
    try {
        const data = await fetchPrioritization();
        showModal('Ward Prioritization Ranking', `
            <div style="max-height: 400px; overflow-y: auto;">
                <table style="width: 100%;">
                    <thead>
                        <tr>
                            <th>Rank</th>
                            <th>Ward</th>
                            <th>Risk Score</th>
                            <th>Priority</th>
                            <th>Time to Outbreak</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${data.ranking.map(w => `
                            <tr>
                                <td><strong>#${w.rank}</strong></td>
                                <td>${w.ward_name}</td>
                                <td>${formatPercent(w.composite_score)}</td>
                                <td><span class="badge badge-${getRiskClass(w.priority)}">${w.priority}</span></td>
                                <td>${w.time_to_outbreak} days</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
            <div class="mt-4">
                <strong>Critical Wards: ${data.critical_count}</strong> |
                <strong>Immediate Action: ${data.immediate_action_required.length}</strong>
            </div>
        `);
    } catch (error) {
        showError('Failed to load prioritization');
    }
    hideLoading();
}

async function showResourceAllocation() {
    showModal('Resource Allocation Advisor', `
        <div class="form-group mb-3">
            <label class="form-label">Resource Type</label>
            <select class="form-select" id="resource-type">
                <option value="sanitation_team">Sanitation Team</option>
                <option value="medical_team">Medical Response Team</option>
                <option value="fogging_unit">Fogging Unit</option>
                <option value="water_testing_kit">Water Testing Kit</option>
            </select>
        </div>
        <div class="form-group mb-3">
            <label class="form-label">Available Units</label>
            <input type="number" class="form-input" id="resource-units" value="3" min="1" max="20">
        </div>
        <button class="btn btn-primary" onclick="runResourceAllocation()">Get Optimal Allocation</button>
        <div id="allocation-result" class="mt-4"></div>
    `);
}

async function runResourceAllocation() {
    const type = document.getElementById('resource-type').value;
    const units = parseInt(document.getElementById('resource-units').value);
    
    try {
        const result = await allocateResources(type, units);
        document.getElementById('allocation-result').innerHTML = `
            <div class="alert alert-info">
                <strong>${result.resource_type}: ${result.units_available} units → ${result.wards_covered} wards</strong>
            </div>
            <table style="width: 100%; margin-top: 1rem;">
                <thead>
                    <tr><th>Ward</th><th>Priority</th><th>Risk After</th><th>Reason</th></tr>
                </thead>
                <tbody>
                    ${result.allocations.map(a => `
                        <tr>
                            <td>${a.ward_name}</td>
                            <td>${a.priority_score}</td>
                            <td>${formatPercent(a.estimated_risk_after)}</td>
                            <td class="text-xs">${a.assignment_reason}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
            ${result.unallocated_high_risk.length > 0 ? `
                <div class="alert alert-warning mt-3">
                    <strong>⚠️ ${result.unallocated_high_risk.length} high-risk wards uncovered</strong>
                    <p class="text-sm">${result.gap_analysis.recommendation}</p>
                </div>
            ` : ''}
        `;
    } catch (error) {
        document.getElementById('allocation-result').innerHTML = `
            <div class="alert alert-danger">Failed to calculate allocation</div>
        `;
    }
}

// Citizen Portal
function showCitizenPortal() {
    const container = document.getElementById('main-content');
    
    container.innerHTML = `
        <div class="section">
            <h1 class="mb-4">👤 Citizen Health Portal</h1>
            <p class="text-muted mb-4">Report health concerns in your ward. Your input helps authorities respond faster.</p>
            
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">📝 Submit Health Report</h3>
                </div>
                <form id="citizen-form">
                    <div class="grid grid-cols-2 gap-4 mb-4">
                        <div class="form-group">
                            <label class="form-label">Ward</label>
                            <select class="form-select" id="report-ward" required>
                                ${state.wards.map(w => `<option value="${w.ward_id}">Ward ${w.ward_id} - ${w.name}</option>`).join('')}
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Issue Type</label>
                            <select class="form-select" id="report-type" required>
                                <option value="fever">Fever / Illness</option>
                                <option value="water">Water Quality Issue</option>
                                <option value="garbage">Garbage / Sanitation</option>
                                <option value="air">Air Quality</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group mb-4">
                        <label class="form-label">Number of people affected</label>
                        <input type="number" class="form-input" id="report-count" value="1" min="1" max="100">
                    </div>
                    <div class="form-group mb-4">
                        <label class="form-label">Description</label>
                        <textarea class="form-textarea" id="report-description" placeholder="Describe the issue..." required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit Report</button>
                </form>
                <div id="report-result" class="mt-4"></div>
            </div>
        </div>
    `;
    
    document.getElementById('citizen-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const report = {
            ward_id: parseInt(document.getElementById('report-ward').value),
            issue_type: document.getElementById('report-type').value,
            count: parseInt(document.getElementById('report-count').value),
            description: document.getElementById('report-description').value
        };
        
        showLoading();
        try {
            const result = await submitCitizenReport(report);
            document.getElementById('report-result').innerHTML = `
                <div class="alert alert-success">
                    <div>
                        <strong>✅ Report Submitted Successfully!</strong>
                        <p class="mt-1">Report ID: ${result.report_id}</p>
                        <p class="mt-1">Updated Ward Risk: <strong>${formatPercent(result.updated_risk)}</strong></p>
                        <p class="text-sm mt-2">${result.impact_note}</p>
                    </div>
                </div>
            `;
            document.getElementById('citizen-form').reset();
        } catch (error) {
            showError('Failed to submit report');
        }
        hideLoading();
    });
}

// UI Helpers
function showModal(title, content) {
    let modal = document.getElementById('modal-container');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'modal-container';
        modal.className = 'modal-overlay';
        modal.innerHTML = `
            <div class="modal">
                <div class="modal-header">
                    <h3 id="modal-title"></h3>
                    <button class="btn btn-secondary btn-sm" onclick="closeModal()">✕</button>
                </div>
                <div class="modal-body" id="modal-body"></div>
            </div>
        `;
        document.body.appendChild(modal);
    }
    
    document.getElementById('modal-title').textContent = title;
    document.getElementById('modal-body').innerHTML = content;
    modal.classList.add('active');
}

function closeModal() {
    document.getElementById('modal-container')?.classList.remove('active');
}

function showLoading() {
    let loader = document.getElementById('loading-overlay');
    if (!loader) {
        loader = document.createElement('div');
        loader.id = 'loading-overlay';
        loader.className = 'loading-overlay';
        loader.innerHTML = `<div class="spinner"></div><p>Loading...</p>`;
        document.body.appendChild(loader);
    }
    loader.style.display = 'flex';
}

function hideLoading() {
    const loader = document.getElementById('loading-overlay');
    if (loader) loader.style.display = 'none';
}

function showError(message) {
    alert(message);
}

// Navigation
async function loadDashboard() {
    showLoading();
    try {
        const data = await fetchWards();
        renderDashboard(data);
    } catch (error) {
        showError('Failed to load dashboard');
    }
    hideLoading();
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadDashboard();
});
