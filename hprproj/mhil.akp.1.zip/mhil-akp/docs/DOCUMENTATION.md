# MHIL - Micro-Health Intelligence Layer
## Documentation

> Ward-level AI-assisted decision-support platform for municipal health governance  
> **Berhampur City, Odisha | 37 Wards**

---

## 🚀 Quick Start

### Prerequisites
- Python 3.9+
- pip

### Installation

```bash
# Navigate to project
cd mhil/backend

# Install dependencies
pip install -r requirements.txt

# Start the server
uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

### Access
- **Dashboard**: http://127.0.0.1:8000
- **API Docs**: http://127.0.0.1:8000/docs
- **Citizen Portal**: http://127.0.0.1:8000/citizen.html

---

## 🏗️ System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    MHIL Architecture                            │
├─────────────────────────────────────────────────────────────────┤
│  LAYER 4: Web Interface (Frontend)                              │
│  ├── Dashboard (Ward Overview)                                  │
│  ├── Ward Detail Page (All indicators + recommendations)       │
│  ├── Citizen Portal (Report submission)                        │
│  └── Simulation Center (What-if scenarios)                     │
├─────────────────────────────────────────────────────────────────┤
│  LAYER 3: Decision Engine                                       │
│  ├── Composite Risk Scorer                                      │
│  ├── Ward Prioritization                                        │
│  ├── Action Recommender (with reasoning)                       │
│  ├── What-If Simulator                                          │
│  ├── Resource Allocator                                         │
│  └── Policy Brief Generator                                     │
├─────────────────────────────────────────────────────────────────┤
│  LAYER 2: ML Intelligence                                       │
│  ├── Risk Predictor (RandomForest)                              │
│  ├── Ward Clusterer (KMeans)                                    │
│  └── Anomaly Detector (IsolationForest)                         │
├─────────────────────────────────────────────────────────────────┤
│  LAYER 1: Data Ingestion                                        │
│  ├── Demographics (37 wards)                                    │
│  ├── Disease History                                            │
│  ├── Environmental Indicators                                   │
│  ├── Healthcare Capacity                                        │
│  └── Citizen Reports                                            │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🤖 ML Models

### 1. Risk Predictor (RandomForest)
- **Purpose**: Predict disease outbreak probability (0-1) for each ward
- **Features**: 11 indicators (disease cases, environmental factors, capacity)
- **Output**: Probability + confidence + feature importance
- **Why RandomForest**: Interpretable, handles mixed features, built-in importance

### 2. Ward Clusterer (KMeans, k=3)
- **Purpose**: Group wards into vulnerability categories
- **Categories**: HIGH / MEDIUM / LOW vulnerability
- **Features**: Population, density, elderly %, capacity, environmental indices
- **Why KMeans**: Simple, explainable, no labels required

### 3. Anomaly Detector (IsolationForest)
- **Purpose**: Detect abnormal disease spikes vs historical baseline
- **Output**: Anomaly flag, warning level (GREEN/YELLOW/ORANGE/RED)
- **Features**: Weekly fever, dengue, waterborne, respiratory cases
- **Why IsolationForest**: Effective for unsupervised outlier detection

---

## 📊 Decision Engine

The decision engine converts ML outputs into governance actions:

| Component | Input | Output |
|-----------|-------|--------|
| Composite Risk | Prediction + Cluster + Anomaly | Score (0-1), Priority (CRITICAL/HIGH/MEDIUM/LOW) |
| Time-to-Outbreak | Risk + Trend + Spikes | Estimated days, range, confidence |
| Action Recommender | Ward data + Risk | Actions with reasoning, urgency, cost/impact |
| What-If Simulator | Intervention type + intensity | Simulated risk change |
| Resource Allocator | Available units + ward risks | Optimal deployment plan |

---

## 🔌 API Endpoints

### Ward Data
- `GET /api/wards` - All wards with risk summary
- `GET /api/wards/{id}` - Detailed ward assessment
- `GET /api/wards/{id}/policy-brief` - Generate policy document

### Risk Analysis
- `GET /api/risk/analysis` - All ML predictions
- `GET /api/risk/prioritization` - Ranked ward list

### Decisions
- `GET /api/decisions/recommendations` - All action recommendations
- `GET /api/decisions/recommendations/{id}` - Ward-specific recommendations

### Simulation
- `POST /api/simulation/whatif` - Intervention simulation
- `POST /api/simulation/delay` - Delay impact simulation

### Resources
- `POST /api/resources/allocate` - Optimal resource allocation
- `GET /api/resources/requirements` - Required resources for coverage

### Citizen Input
- `POST /api/citizen/report` - Submit health report
- `GET /api/citizen/reports` - View all reports

### Explainability
- `GET /api/explain/ward/{id}` - Detailed risk explanation
- `GET /api/explain/models` - Model documentation

---

## ⚠️ Assumptions & Limitations

### Assumptions
1. Ward-level granularity is sufficient for decision-making
2. Synthetic data patterns reflect realistic disease dynamics
3. 5-year trend is representative of disease trajectory
4. Citizen reports provide accurate ground truth

### Limitations
1. **Data**: Synthetic - real deployment needs actual civic data
2. **ML Accuracy**: Models trained on limited synthetic data
3. **Time-to-Outbreak**: Heuristic-based, not epidemiological model
4. **No GIS**: Map visualization not implemented
5. **Single-city**: Currently hardcoded for Berhampur

---

## 🔮 Future Scalability

1. **Real Data Integration**: Connect to municipal health APIs
2. **Multi-City Deployment**: Parameterize city/ward structure
3. **Advanced ML**: LSTM for time-series, graph neural networks
4. **GIS Maps**: Folium/Leaflet integration
5. **Mobile App**: React Native citizen app
6. **Alert System**: SMS/WhatsApp notifications
7. **Historical Analysis**: Long-term trend dashboards
8. **Multi-language**: Odia language support

---

## 📁 Project Structure

```
mhil/
├── backend/
│   ├── main.py                 # FastAPI application
│   ├── requirements.txt        
│   ├── data/                   # Synthetic ward datasets
│   │   ├── demographics.json
│   │   ├── disease_history.json
│   │   ├── environmental.json
│   │   ├── healthcare_capacity.json
│   │   └── citizen_reports.json
│   ├── ml/                     # ML modules
│   │   ├── risk_predictor.py   # RandomForest
│   │   ├── clustering.py       # KMeans
│   │   └── anomaly_detector.py # IsolationForest
│   └── engine/                 # Decision logic
│       ├── decision_engine.py
│       ├── simulator.py
│       └── resource_allocator.py
├── frontend/
│   ├── index.html              # Main dashboard
│   ├── citizen.html            # Citizen portal
│   ├── simulation.html         # What-if simulator
│   ├── css/styles.css
│   └── js/app.js
└── docs/
    └── DOCUMENTATION.md
```

---

## 🎯 Design Philosophy

1. **Explainability > Accuracy**: Every decision shows its reasoning
2. **Governance-First**: Built for municipal officers, not data scientists
3. **Action-Oriented**: Outputs are actionable recommendations
4. **Transparent AI**: Feature contributions visible at all levels
5. **Decision Support**: Assists humans, doesn't replace them

---

*MHIL - Micro-Health Intelligence Layer*  
*National Hackathon Prototype | Berhampur City, Odisha*
