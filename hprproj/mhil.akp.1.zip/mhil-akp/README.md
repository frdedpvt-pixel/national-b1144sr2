# MHIL - Micro-Health Intelligence Layer
> **Ward-level AI-assisted decision-support platform for municipal health governance**  
> Berhampur City, Odisha | 37 Wards | National Hackathon Prototype

![Status](https://img.shields.io/badge/Status-Prototype-blue)
![Python](https://img.shields.io/badge/Python-3.9+-green)
![FastAPI](https://img.shields.io/badge/FastAPI-0.104+-red)

---

## 🎯 What is MHIL?

MHIL is a **decision intelligence system** that sits between civic data and government action. It helps Municipal Health Officers:

- **Predict** disease outbreak risk per ward
- **Prioritize** which wards need attention first
- **Recommend** specific actions with reasoning
- **Simulate** what-if scenarios before committing resources
- **Explain** every decision transparently

> ⚠️ This is NOT a hospital management system, diagnosis app, or static dashboard.  
> ✅ This IS a governance decision-support brain.

---

## 🚀 Quick Start

```bash
# 1. Navigate to backend
cd mhil/backend

# 2. Install dependencies
pip install -r requirements.txt

# 3. Start server
uvicorn main:app --reload --host 127.0.0.1 --port 8000

# 4. Open browser
# Dashboard: http://127.0.0.1:8000
# API Docs:  http://127.0.0.1:8000/docs
```

---

## 🏗️ Architecture

| Layer | Components | Technology |
|-------|------------|------------|
| **Data** | 5 datasets for 37 wards | JSON |
| **ML** | Risk Prediction, Clustering, Anomaly Detection | RandomForest, KMeans, IsolationForest |
| **Decision** | Scoring, Recommendations, Simulation, Resource Allocation | Python |
| **Web** | Dashboard, Ward Details, Citizen Portal, Simulation | HTML, CSS, JavaScript, FastAPI |

---

## 🤖 AI Features

1. **Risk Prediction** - ML probability of disease outbreak
2. **Ward Clustering** - Vulnerability grouping (High/Medium/Low)
3. **Anomaly Detection** - Spike alerts from historical baselines
4. **Explainable AI** - Feature contributions visible for every prediction
5. **What-If Simulation** - Test interventions before deployment
6. **Resource Advisor** - Optimal allocation of limited resources
7. **Policy Brief Generator** - One-click summaries for officials

---

## 📊 Key Screens

- **Dashboard** - Overview of all 37 wards with risk indicators
- **Ward Detail** - Complete assessment with recommendations
- **Simulation Center** - Intervention and delay modeling
- **Citizen Portal** - Public health reporting

---

## 📁 Project Structure

```
mhil/
├── backend/
│   ├── main.py              # FastAPI server
│   ├── data/                # 37-ward datasets
│   ├── ml/                  # ML models
│   └── engine/              # Decision logic
├── frontend/
│   ├── index.html           # Dashboard
│   ├── citizen.html         # Citizen portal
│   ├── simulation.html      # What-if simulator
│   ├── css/ & js/           # Styles & scripts
└── docs/
    └── DOCUMENTATION.md     # Full documentation
```

---

## 🎯 Design Philosophy

- **Explainability > Accuracy**: Every decision shows its reasoning
- **Governance-First**: Built for municipal officers, not data scientists
- **Action-Oriented**: Outputs are actionable recommendations
- **Decision Support**: Assists humans, doesn't replace them

---

## 📖 Documentation

See [docs/DOCUMENTATION.md](docs/DOCUMENTATION.md) for:
- Full architecture details
- API reference
- Model explanations
- Assumptions & limitations
- Future roadmap

---

*MHIL - Micro-Health Intelligence Layer*  
*National Hackathon Prototype | 2026*