"""
Decision Engine - Core governance decision-making logic
Converts ML outputs into actionable recommendations for authorities
"""

from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
import math


class DecisionEngine:
    """
    The decision-making brain that converts AI predictions into governance actions.
    Separates decision logic from ML inference for clarity and auditability.
    """
    
    # Action definitions with metadata
    ACTIONS = {
        "sanitation_drive": {
            "name": "Sanitation Drive",
            "description": "Deploy sanitation teams for intensive cleaning",
            "cost": "MEDIUM",
            "impact": "HIGH",
            "time_to_effect": 3,
            "triggers": ["garbage_backlog", "water_stagnation"]
        },
        "fogging": {
            "name": "Fogging Operation",
            "description": "Anti-mosquito fogging to prevent vector-borne diseases",
            "cost": "LOW",
            "impact": "MEDIUM",
            "time_to_effect": 1,
            "triggers": ["dengue_cases", "water_stagnation"]
        },
        "medical_camp": {
            "name": "Medical Health Camp",
            "description": "Set up temporary health camp for screening and treatment",
            "cost": "HIGH",
            "impact": "HIGH",
            "time_to_effect": 2,
            "triggers": ["fever_outbreak", "disease_spike"]
        },
        "water_testing": {
            "name": "Water Quality Testing",
            "description": "Comprehensive water source testing and treatment",
            "cost": "LOW",
            "impact": "MEDIUM",
            "time_to_effect": 2,
            "triggers": ["waterborne_cases", "water_quality"]
        },
        "public_alert": {
            "name": "Public Health Alert",
            "description": "Issue public advisory via SMS, loudspeakers, and social media",
            "cost": "LOW",
            "impact": "MEDIUM",
            "time_to_effect": 0,
            "triggers": ["anomaly_detected", "high_risk"]
        },
        "school_advisory": {
            "name": "School Health Advisory",
            "description": "Alert schools for preventive measures and potential closure",
            "cost": "LOW",
            "impact": "LOW",
            "time_to_effect": 1,
            "triggers": ["respiratory_cases", "fever_outbreak"]
        }
    }
    
    def __init__(self):
        self.weights = {
            "risk_prediction": 0.40,
            "vulnerability_cluster": 0.30,
            "anomaly_flag": 0.30
        }
    
    def compute_composite_risk(
        self,
        risk_prediction: Dict,
        vulnerability: Dict,
        anomaly: Dict
    ) -> Dict[str, Any]:
        """
        Calculate composite risk score from all ML outputs.
        Returns unified risk assessment for a ward.
        """
        # Base risk from prediction
        base_risk = risk_prediction.get('risk_probability', 0.5)
        
        # Vulnerability multiplier
        vuln_level = vulnerability.get('vulnerability_level', 'MEDIUM')
        vuln_multiplier = {"HIGH": 1.3, "MEDIUM": 1.0, "LOW": 0.7}.get(vuln_level, 1.0)
        
        # Anomaly bonus
        anomaly_bonus = 0.15 if anomaly.get('is_anomaly', False) else 0
        
        # Warning level bonus
        warning_level = anomaly.get('warning_level', 'GREEN')
        warning_bonus = {"RED": 0.2, "ORANGE": 0.1, "YELLOW": 0.05, "GREEN": 0}.get(warning_level, 0)
        
        # Compute composite score
        composite = min(1.0, (base_risk * vuln_multiplier) + anomaly_bonus + warning_bonus)
        
        # Determine priority label
        if composite >= 0.75:
            priority = "CRITICAL"
            urgency = "IMMEDIATE"
        elif composite >= 0.55:
            priority = "HIGH"
            urgency = "WITHIN_24H"
        elif composite >= 0.35:
            priority = "MEDIUM"
            urgency = "WITHIN_3_DAYS"
        else:
            priority = "LOW"
            urgency = "MONITOR_ONLY"
        
        # Calculate confidence
        confidences = [
            risk_prediction.get('confidence', 0.5),
            vulnerability.get('confidence', 0.5)
        ]
        avg_confidence = sum(confidences) / len(confidences)
        
        return {
            "composite_score": float(round(composite, 3)),
            "priority": priority,
            "urgency": urgency,
            "confidence": float(round(avg_confidence, 3)),
            "breakdown": {
                "risk_prediction": float(round(base_risk, 3)),
                "vulnerability_level": vuln_level,
                "anomaly_detected": bool(anomaly.get('is_anomaly', False)),
                "warning_level": warning_level
            }
        }
    
    def estimate_time_to_outbreak(
        self,
        composite_risk: float,
        trend: str,
        anomaly_spikes: List[Dict]
    ) -> Dict[str, Any]:
        """
        Estimate days until potential outbreak based on risk trajectory.
        """
        # Base estimate from composite risk
        if composite_risk >= 0.8:
            base_days = 3
        elif composite_risk >= 0.6:
            base_days = 7
        elif composite_risk >= 0.4:
            base_days = 14
        else:
            base_days = 21
        
        # Adjust for trend
        trend_multiplier = {
            "increasing": 0.7,
            "stable": 1.0,
            "decreasing": 1.5
        }.get(trend, 1.0)
        
        # Adjust for anomaly spikes
        spike_reduction = len(anomaly_spikes) * 0.5 if anomaly_spikes else 0
        
        estimated_days = max(1, int(base_days * trend_multiplier - spike_reduction))
        
        # Confidence based on data quality
        if len(anomaly_spikes) > 0 and trend == "increasing":
            confidence = "HIGH"
        elif composite_risk > 0.5:
            confidence = "MEDIUM"
        else:
            confidence = "LOW"
        
        return {
            "estimated_days": estimated_days,
            "confidence": confidence,
            "range": f"{max(1, estimated_days - 2)} - {estimated_days + 3} days",
            "basis": f"Based on {composite_risk:.0%} risk, {trend} trend, {len(anomaly_spikes)} anomaly spikes"
        }
    
    def recommend_actions(
        self,
        ward_data: Dict,
        composite_risk: Dict,
        anomaly: Dict
    ) -> List[Dict[str, Any]]:
        """
        Generate prioritized action recommendations with reasoning.
        """
        recommendations = []
        risk_score = composite_risk.get('composite_score', 0.5)
        priority = composite_risk.get('priority', 'MEDIUM')
        spikes = anomaly.get('spikes_detected', [])
        
        # Determine which actions are triggered
        triggered_actions = []
        reasons = {}
        
        # Check garbage/sanitation conditions
        if ward_data.get('garbage_backlog_idx', 0) > 0.6:
            triggered_actions.append('sanitation_drive')
            reasons['sanitation_drive'] = f"Garbage backlog index ({ward_data.get('garbage_backlog_idx'):.2f}) exceeds threshold"
        
        # Check water stagnation
        if ward_data.get('water_stagnation_idx', 0) > 0.5:
            if 'sanitation_drive' not in triggered_actions:
                triggered_actions.append('sanitation_drive')
            triggered_actions.append('fogging')
            reasons['fogging'] = f"Water stagnation ({ward_data.get('water_stagnation_idx'):.2f}) creates vector breeding risk"
        
        # Check dengue cases
        if ward_data.get('dengue_cases', 0) > 10:
            if 'fogging' not in triggered_actions:
                triggered_actions.append('fogging')
            reasons['fogging'] = reasons.get('fogging', '') + f"; {ward_data.get('dengue_cases')} dengue cases reported"
        
        # Check for fever outbreak
        if ward_data.get('fever_weekly', 0) > 40 or any(s.get('indicator') == 'Weekly Fever Cases' for s in spikes):
            triggered_actions.append('medical_camp')
            triggered_actions.append('public_alert')
            reasons['medical_camp'] = f"Elevated fever cases ({ward_data.get('fever_weekly')}) require medical intervention"
            reasons['public_alert'] = "Community awareness needed for fever prevention"
        
        # Check water quality
        if ward_data.get('water_quality_idx', 1) < 0.6 or ward_data.get('waterborne_cases', 0) > 10:
            triggered_actions.append('water_testing')
            reasons['water_testing'] = f"Water quality concerns (index: {ward_data.get('water_quality_idx'):.2f}, waterborne cases: {ward_data.get('waterborne_cases')})"
        
        # Check respiratory cases (school advisory)
        if ward_data.get('respiratory_cases', 0) > 25:
            triggered_actions.append('school_advisory')
            reasons['school_advisory'] = f"High respiratory cases ({ward_data.get('respiratory_cases')}) affecting children"
        
        # Add public alert for high-risk wards if not already added
        if priority in ['CRITICAL', 'HIGH'] and 'public_alert' not in triggered_actions:
            triggered_actions.append('public_alert')
            reasons['public_alert'] = f"Ward is {priority} priority - community should be informed"
        
        # Build recommendations with detailed reasoning
        for action_id in set(triggered_actions):
            action = self.ACTIONS.get(action_id, {})
            
            # Determine urgency based on priority
            if priority == 'CRITICAL':
                urgency = "IMMEDIATE"
            elif priority == 'HIGH':
                urgency = "WITHIN_24H"
            elif priority == 'MEDIUM':
                urgency = "WITHIN_3_DAYS"
            else:
                urgency = "MONITOR_ONLY"
            
            recommendations.append({
                "action_id": action_id,
                "action_name": action.get('name', action_id),
                "description": action.get('description', ''),
                "urgency": urgency,
                "cost_level": action.get('cost', 'MEDIUM'),
                "impact_level": action.get('impact', 'MEDIUM'),
                "time_to_effect_days": action.get('time_to_effect', 2),
                "reason_for_action": reasons.get(action_id, 'General risk mitigation'),
                "reason_not_others": self._explain_exclusions(action_id, triggered_actions)
            })
        
        # Sort by urgency and impact
        urgency_order = {"IMMEDIATE": 0, "WITHIN_24H": 1, "WITHIN_3_DAYS": 2, "MONITOR_ONLY": 3}
        recommendations.sort(key=lambda x: (urgency_order.get(x['urgency'], 4), x['cost_level']))
        
        return recommendations
    
    def _explain_exclusions(self, included: str, all_triggered: List[str]) -> str:
        """Explain why certain actions were not recommended."""
        excluded = [a for a in self.ACTIONS.keys() if a not in all_triggered]
        if not excluded:
            return "All relevant actions are recommended."
        
        explanations = []
        if 'medical_camp' in excluded:
            explanations.append("Medical camp not needed as fever cases are within normal range")
        if 'fogging' in excluded:
            explanations.append("Fogging not required - low vector-borne disease risk")
        if 'school_advisory' in excluded:
            explanations.append("School advisory not needed - respiratory cases are low")
        if 'water_testing' in excluded:
            explanations.append("Water testing can be deferred - quality indicators are acceptable")
        
        return "; ".join(explanations[:2]) if explanations else "Other actions have lower priority for current conditions"
    
    def get_cost_impact_analysis(self, recommendations: List[Dict]) -> List[Dict]:
        """Generate cost vs impact analysis table for recommendations."""
        analysis = []
        
        cost_values = {"LOW": 1, "MEDIUM": 2, "HIGH": 3}
        impact_values = {"LOW": 1, "MEDIUM": 2, "HIGH": 3}
        
        for rec in recommendations:
            cost = cost_values.get(rec.get('cost_level', 'MEDIUM'), 2)
            impact = impact_values.get(rec.get('impact_level', 'MEDIUM'), 2)
            efficiency = impact / cost
            
            analysis.append({
                "action": rec.get('action_name'),
                "cost": rec.get('cost_level'),
                "impact": rec.get('impact_level'),
                "efficiency_score": float(round(efficiency, 2)),
                "recommendation": "HIGHLY RECOMMENDED" if efficiency >= 1.5 else "RECOMMENDED" if efficiency >= 1.0 else "OPTIONAL"
            })
        
        analysis.sort(key=lambda x: x['efficiency_score'], reverse=True)
        return analysis
    
    def generate_root_cause_analysis(
        self,
        ward_data: Dict,
        risk_prediction: Dict,
        anomaly: Dict
    ) -> Dict[str, Any]:
        """
        Generate explainable root cause analysis for a ward's risk.
        """
        factors = []
        
        # Analyze feature contributions from risk prediction
        contributions = risk_prediction.get('feature_contributions', {})
        top_factors = risk_prediction.get('top_risk_factors', [])
        
        for factor in top_factors:
            factors.append({
                "factor": factor.get('factor'),
                "contribution": f"{factor.get('contribution_pct')}%",
                "severity": "HIGH" if factor.get('contribution_pct', 0) > 15 else "MEDIUM"
            })
        
        # Add anomaly-based factors
        for spike in anomaly.get('spikes_detected', []):
            factors.append({
                "factor": f"Anomalous {spike.get('indicator')}",
                "contribution": spike.get('deviation', 'N/A'),
                "severity": spike.get('severity', 'MODERATE')
            })
        
        # Generate text explanation
        explanation_parts = []
        if ward_data.get('garbage_backlog_idx', 0) > 0.7:
            explanation_parts.append(f"Severe garbage backlog ({ward_data.get('garbage_backlog_idx'):.0%}) is creating unsanitary conditions")
        if ward_data.get('water_stagnation_idx', 0) > 0.6:
            explanation_parts.append(f"Water stagnation ({ward_data.get('water_stagnation_idx'):.0%}) provides breeding grounds for mosquitoes")
        if ward_data.get('aqi', 0) > 150:
            explanation_parts.append(f"Poor air quality (AQI: {ward_data.get('aqi')}) increases respiratory vulnerability")
        if ward_data.get('fever_weekly', 0) > 50:
            explanation_parts.append(f"High weekly fever cases ({ward_data.get('fever_weekly')}) indicate active disease transmission")
        if ward_data.get('hospital_capacity_score', 1) < 0.5:
            explanation_parts.append("Limited healthcare capacity reduces response effectiveness")
        
        text_explanation = ". ".join(explanation_parts) if explanation_parts else "Risk factors are within moderate range. Continue routine monitoring."
        
        return {
            "factor_breakdown": factors,
            "text_explanation": text_explanation,
            "data_quality": self._assess_data_quality(ward_data),
            "confidence_indicator": risk_prediction.get('confidence', 0.5)
        }
    
    def _assess_data_quality(self, ward_data: Dict) -> Dict[str, Any]:
        """Assess the quality and completeness of ward data."""
        required_fields = [
            'fever_weekly', 'dengue_cases', 'aqi', 'garbage_backlog_idx',
            'water_quality_idx', 'hospital_capacity_score', 'population'
        ]
        
        present = sum(1 for f in required_fields if f in ward_data and ward_data[f] is not None)
        completeness = present / len(required_fields)
        
        # Check for stale data (simulated)
        freshness = "FRESH"  # Would check timestamps in production
        
        return {
            "completeness": f"{completeness:.0%}",
            "freshness": freshness,
            "missing_fields": [f for f in required_fields if f not in ward_data or ward_data[f] is None],
            "quality_score": "HIGH" if completeness > 0.9 else "MEDIUM" if completeness > 0.7 else "LOW"
        }
    
    def rank_wards(self, all_ward_assessments: List[Dict]) -> List[Dict]:
        """Rank all wards by composite risk for prioritization."""
        ranked = sorted(
            all_ward_assessments,
            key=lambda x: x.get('composite_score', 0),
            reverse=True
        )
        
        for i, ward in enumerate(ranked):
            ward['rank'] = i + 1
        
        return ranked


def generate_policy_brief(
    ward_data: Dict,
    composite_risk: Dict,
    recommendations: List[Dict],
    time_to_outbreak: Dict
) -> str:
    """Generate one-click policy brief for officials."""
    ward_name = ward_data.get('name', f"Ward {ward_data.get('ward_id')}")
    priority = composite_risk.get('priority', 'MEDIUM')
    risk_score = composite_risk.get('composite_score', 0.5)
    
    brief = f"""
================================================================================
                    MHIL - MUNICIPAL HEALTH INTELLIGENCE BRIEF
                    Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}
================================================================================

WARD: {ward_name} (ID: {ward_data.get('ward_id')})
PRIORITY LEVEL: {priority}
COMPOSITE RISK SCORE: {risk_score:.1%}

--------------------------------------------------------------------------------
SITUATION SUMMARY
--------------------------------------------------------------------------------
Population: {ward_data.get('population', 'N/A'):,}
Time to Potential Outbreak: {time_to_outbreak.get('range', 'N/A')}
Confidence: {time_to_outbreak.get('confidence', 'N/A')}

Key Indicators:
  - Weekly Fever Cases: {ward_data.get('fever_weekly', 'N/A')}
  - Dengue Cases: {ward_data.get('dengue_cases', 'N/A')}
  - Air Quality Index: {ward_data.get('aqi', 'N/A')}
  - Garbage Backlog: {ward_data.get('garbage_backlog_idx', 0):.0%}
  - Water Stagnation: {ward_data.get('water_stagnation_idx', 0):.0%}

--------------------------------------------------------------------------------
RECOMMENDED ACTIONS
--------------------------------------------------------------------------------
"""
    
    for i, rec in enumerate(recommendations[:3], 1):
        brief += f"""
{i}. {rec.get('action_name', 'Unknown')} [{rec.get('urgency', 'N/A')}]
   Reason: {rec.get('reason_for_action', 'N/A')}
   Cost: {rec.get('cost_level', 'N/A')} | Impact: {rec.get('impact_level', 'N/A')}
"""
    
    brief += f"""
--------------------------------------------------------------------------------
DECISION GUIDANCE
--------------------------------------------------------------------------------
{'⚠️ IMMEDIATE ACTION REQUIRED - Deploy resources within 24 hours' if priority == 'CRITICAL' else
 '🔶 HIGH PRIORITY - Action recommended within 48 hours' if priority == 'HIGH' else
 '📋 MODERATE PRIORITY - Schedule interventions within the week' if priority == 'MEDIUM' else
 '✅ LOW PRIORITY - Continue routine monitoring'}

================================================================================
                         This brief is auto-generated by MHIL
                    Micro-Health Intelligence Layer | Berhampur City
================================================================================
"""
    return brief
