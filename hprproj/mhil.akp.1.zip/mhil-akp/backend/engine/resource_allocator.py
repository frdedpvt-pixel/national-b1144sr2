"""
Resource Allocation Advisor - Optimize deployment of limited resources
Recommends optimal ward assignments for sanitation teams, medical camps, etc.
"""

from typing import Dict, List, Any, Tuple
import heapq


class ResourceAllocator:
    """
    Optimizes allocation of limited resources across high-risk wards.
    Uses risk-weighted scoring to maximize impact per resource unit.
    """
    
    def __init__(self):
        # Resource type configurations
        self.resource_types = {
            "sanitation_team": {
                "name": "Sanitation Team",
                "impact_factor": 0.25,
                "coverage_per_unit": 1,  # 1 team per ward
                "setup_time_hours": 4
            },
            "medical_team": {
                "name": "Medical Response Team",
                "impact_factor": 0.30,
                "coverage_per_unit": 1,
                "setup_time_hours": 2
            },
            "fogging_unit": {
                "name": "Fogging Unit",
                "impact_factor": 0.20,
                "coverage_per_unit": 2,  # 1 unit can cover 2 wards
                "setup_time_hours": 1
            },
            "water_testing_kit": {
                "name": "Water Testing Kit",
                "impact_factor": 0.15,
                "coverage_per_unit": 3,  # Can test 3 wards
                "setup_time_hours": 6
            }
        }
    
    def calculate_priority_score(
        self,
        ward_data: Dict,
        composite_risk: float,
        time_to_outbreak: int
    ) -> float:
        """
        Calculate deployment priority score for a ward.
        Higher score = higher priority for resource allocation.
        """
        # Base score from composite risk
        base = composite_risk * 100
        
        # Population weight - more people at risk = higher priority
        population = ward_data.get('population', 10000)
        pop_factor = min(2.0, population / 10000)
        
        # Urgency factor - closer outbreak = higher priority
        urgency = max(0.5, 1 - (time_to_outbreak / 21))
        
        # Healthcare capacity factor - low capacity = more urgent
        capacity = ward_data.get('hospital_capacity_score', 0.6)
        capacity_factor = 1.5 - capacity
        
        priority_score = base * pop_factor * urgency * capacity_factor
        
        return float(round(priority_score, 2))
    
    def allocate_resources(
        self,
        wards_data: List[Dict],
        risks: Dict[int, Dict],
        resource_type: str,
        available_units: int
    ) -> Dict[str, Any]:
        """
        Allocate resources optimally across wards.
        
        Args:
            wards_data: List of ward data dictionaries
            risks: Dict mapping ward_id to risk assessment
            resource_type: Type of resource to allocate
            available_units: Number of resource units available
        
        Returns:
            Allocation plan with assignments and impact estimates
        """
        if resource_type not in self.resource_types:
            return {"error": f"Unknown resource type: {resource_type}"}
        
        resource_config = self.resource_types[resource_type]
        coverage_per_unit = resource_config.get('coverage_per_unit', 1)
        impact_factor = resource_config.get('impact_factor', 0.2)
        
        # Calculate priority scores for all wards
        ward_priorities = []
        for ward in wards_data:
            ward_id = ward.get('ward_id')
            risk_data = risks.get(ward_id, {})
            composite_risk = risk_data.get('composite_score', 0.5)
            time_to_outbreak = risk_data.get('time_to_outbreak', {}).get('estimated_days', 14)
            
            priority = self.calculate_priority_score(ward, composite_risk, time_to_outbreak)
            
            ward_priorities.append({
                'ward_id': ward_id,
                'ward_name': ward.get('name', f"Ward {ward_id}"),
                'priority_score': priority,
                'current_risk': composite_risk,
                'population': ward.get('population', 0),
                'time_to_outbreak': time_to_outbreak
            })
        
        # Sort by priority (highest first)
        ward_priorities.sort(key=lambda x: x['priority_score'], reverse=True)
        
        # Allocate resources
        total_wards_to_cover = available_units * coverage_per_unit
        allocations = []
        total_population_covered = 0
        total_risk_reduced = 0
        
        for ward in ward_priorities[:total_wards_to_cover]:
            risk_reduction = ward['current_risk'] * impact_factor
            
            allocations.append({
                'ward_id': ward['ward_id'],
                'ward_name': ward['ward_name'],
                'priority_score': float(ward['priority_score']),
                'current_risk': float(round(ward['current_risk'], 3)),
                'estimated_risk_after': float(round(ward['current_risk'] - risk_reduction, 3)),
                'population': ward['population'],
                'time_to_outbreak_days': ward['time_to_outbreak'],
                'assignment_reason': self._generate_assignment_reason(ward)
            })
            
            total_population_covered += ward['population']
            total_risk_reduced += risk_reduction
        
        # Identify unallocated high-risk wards
        unallocated_high_risk = [
            w for w in ward_priorities[total_wards_to_cover:]
            if w['current_risk'] > 0.6
        ]
        
        return {
            'resource_type': resource_config.get('name'),
            'units_available': available_units,
            'wards_covered': len(allocations),
            'allocations': allocations,
            'summary': {
                'total_population_covered': total_population_covered,
                'average_risk_reduction': float(round(total_risk_reduced / max(1, len(allocations)), 3)),
                'setup_time_hours': resource_config.get('setup_time_hours', 4)
            },
            'unallocated_high_risk': [
                {'ward_id': w['ward_id'], 'ward_name': w['ward_name'], 'risk': w['current_risk']}
                for w in unallocated_high_risk[:5]
            ],
            'gap_analysis': self._analyze_resource_gap(
                len(unallocated_high_risk),
                ward_priorities
            )
        }
    
    def _generate_assignment_reason(self, ward: Dict) -> str:
        """Generate human-readable reason for assignment."""
        reasons = []
        
        if ward['priority_score'] > 80:
            reasons.append("highest priority score")
        elif ward['priority_score'] > 60:
            reasons.append("high priority score")
        
        if ward['current_risk'] > 0.7:
            reasons.append(f"critical risk level ({ward['current_risk']:.0%})")
        elif ward['current_risk'] > 0.5:
            reasons.append(f"elevated risk ({ward['current_risk']:.0%})")
        
        if ward['time_to_outbreak'] <= 5:
            reasons.append(f"imminent outbreak risk ({ward['time_to_outbreak']} days)")
        
        if ward['population'] > 15000:
            reasons.append(f"large population ({ward['population']:,})")
        
        return "Assigned due to " + ", ".join(reasons) if reasons else "Standard priority allocation"
    
    def _analyze_resource_gap(
        self,
        unallocated_high_risk_count: int,
        all_wards: List[Dict]
    ) -> Dict[str, Any]:
        """Analyze the gap between available and needed resources."""
        high_risk_wards = [w for w in all_wards if w['current_risk'] > 0.6]
        critical_wards = [w for w in all_wards if w['current_risk'] > 0.8]
        
        return {
            'total_high_risk_wards': len(high_risk_wards),
            'critical_wards_uncovered': len([w for w in critical_wards if w in all_wards[len(all_wards):]]),
            'unallocated_high_risk': unallocated_high_risk_count,
            'recommendation': self._get_gap_recommendation(unallocated_high_risk_count, len(critical_wards))
        }
    
    def _get_gap_recommendation(self, unallocated: int, critical: int) -> str:
        """Generate recommendation based on resource gap."""
        if unallocated == 0:
            return "✅ Resources sufficient - all high-risk wards covered"
        elif unallocated <= 2:
            return f"⚠️ Minor gap - {unallocated} high-risk ward(s) uncovered. Consider reallocation."
        elif unallocated <= 5:
            return f"🔶 Moderate gap - {unallocated} high-risk wards uncovered. Request additional resources."
        else:
            return f"🚨 Critical gap - {unallocated} high-risk wards uncovered. Escalate to district level for support."
    
    def compare_allocation_strategies(
        self,
        wards_data: List[Dict],
        risks: Dict[int, Dict],
        resource_type: str,
        available_units: int
    ) -> Dict[str, Any]:
        """
        Compare different allocation strategies and recommend the best.
        """
        strategies = {}
        
        # Strategy 1: Risk-priority (default)
        strategies['risk_priority'] = self.allocate_resources(
            wards_data, risks, resource_type, available_units
        )
        
        # Strategy 2: Population-weighted
        pop_weighted_risks = {}
        for ward_id, risk in risks.items():
            ward = next((w for w in wards_data if w.get('ward_id') == ward_id), {})
            pop_factor = ward.get('population', 10000) / 10000
            pop_weighted_risks[ward_id] = {
                **risk,
                'composite_score': risk.get('composite_score', 0.5) * pop_factor
            }
        strategies['population_weighted'] = self.allocate_resources(
            wards_data, pop_weighted_risks, resource_type, available_units
        )
        
        # Strategy 3: Urgency-first (time to outbreak)
        urgency_risks = {}
        for ward_id, risk in risks.items():
            time_factor = 1 / max(1, risk.get('time_to_outbreak', {}).get('estimated_days', 14))
            urgency_risks[ward_id] = {
                **risk,
                'composite_score': risk.get('composite_score', 0.5) + (time_factor * 0.5)
            }
        strategies['urgency_first'] = self.allocate_resources(
            wards_data, urgency_risks, resource_type, available_units
        )
        
        # Determine best strategy
        best_strategy = max(
            strategies.items(),
            key=lambda x: x[1].get('summary', {}).get('total_population_covered', 0)
        )
        
        return {
            'strategies': strategies,
            'recommended_strategy': best_strategy[0],
            'recommendation_reason': f"Maximizes population coverage while addressing highest risks",
            'comparison_summary': {
                strategy: {
                    'population_covered': data.get('summary', {}).get('total_population_covered', 0),
                    'avg_risk_reduction': data.get('summary', {}).get('average_risk_reduction', 0)
                }
                for strategy, data in strategies.items()
            }
        }
    
    def get_resource_requirements(
        self,
        wards_data: List[Dict],
        risks: Dict[int, Dict],
        target_coverage: str = "all_high_risk"
    ) -> Dict[str, Any]:
        """
        Calculate resource requirements to achieve a target coverage level.
        """
        high_risk_wards = [
            w for w in wards_data
            if risks.get(w.get('ward_id'), {}).get('composite_score', 0) > 0.6
        ]
        
        critical_wards = [
            w for w in wards_data
            if risks.get(w.get('ward_id'), {}).get('composite_score', 0) > 0.8
        ]
        
        requirements = {}
        for resource_type, config in self.resource_types.items():
            coverage = config.get('coverage_per_unit', 1)
            
            if target_coverage == "all_high_risk":
                needed = (len(high_risk_wards) + coverage - 1) // coverage
            elif target_coverage == "critical_only":
                needed = (len(critical_wards) + coverage - 1) // coverage
            else:
                needed = (len(wards_data) + coverage - 1) // coverage
            
            requirements[resource_type] = {
                'resource_name': config.get('name'),
                'units_needed': needed,
                'wards_to_cover': len(high_risk_wards) if target_coverage == "all_high_risk" else len(critical_wards)
            }
        
        return {
            'target_coverage': target_coverage,
            'high_risk_ward_count': len(high_risk_wards),
            'critical_ward_count': len(critical_wards),
            'requirements': requirements
        }
