"""
What-If Simulation Module - Simulate intervention impacts on risk
Allows authorities to explore scenarios before committing resources
"""

from typing import Dict, List, Any, Optional
import copy


class WhatIfSimulator:
    """
    Simulates the impact of interventions and delays on ward risk scores.
    Enables decision-makers to explore scenarios before taking action.
    """
    
    # Intervention impact models (based on empirical estimates)
    INTERVENTION_IMPACTS = {
        "sanitation_improvement": {
            "name": "Sanitation Improvement",
            "description": "Increase in sanitation coverage / garbage clearance",
            "affects": ["garbage_backlog_idx", "water_stagnation_idx"],
            "max_reduction": 0.4,  # Max risk reduction at 100% improvement
            "time_to_effect_days": 3
        },
        "fogging_operation": {
            "name": "Fogging Operation",
            "description": "Anti-mosquito fogging coverage",
            "affects": ["dengue_cases"],
            "max_reduction": 0.25,
            "time_to_effect_days": 1
        },
        "medical_camp_deployment": {
            "name": "Medical Camp Deployment",
            "description": "Temporary healthcare capacity increase",
            "affects": ["hospital_capacity_score", "fever_weekly"],
            "max_reduction": 0.3,
            "time_to_effect_days": 2
        },
        "water_treatment": {
            "name": "Water Treatment",
            "description": "Water quality improvement measures",
            "affects": ["water_quality_idx", "waterborne_cases"],
            "max_reduction": 0.25,
            "time_to_effect_days": 5
        },
        "delay": {
            "name": "Action Delay",
            "description": "Impact of delaying intervention",
            "affects": ["all"],
            "risk_increase_per_day": 0.03,
            "max_increase": 0.25
        }
    }
    
    def __init__(self, risk_predictor=None):
        self.risk_predictor = risk_predictor
    
    def simulate_intervention(
        self,
        ward_data: Dict,
        current_risk: float,
        intervention: str,
        intensity_percent: int
    ) -> Dict[str, Any]:
        """
        Simulate the effect of an intervention on ward risk.
        
        Args:
            ward_data: Current ward data
            current_risk: Current risk score (0-1)
            intervention: Type of intervention
            intensity_percent: Intervention intensity (0-100)
        
        Returns:
            Simulation result with new risk score
        """
        if intervention not in self.INTERVENTION_IMPACTS:
            return {"error": f"Unknown intervention: {intervention}"}
        
        impact_model = self.INTERVENTION_IMPACTS[intervention]
        intensity = intensity_percent / 100.0
        
        # Calculate risk reduction
        max_reduction = impact_model.get('max_reduction', 0.2)
        risk_reduction = max_reduction * intensity
        
        # Apply reduction
        new_risk = max(0.05, current_risk - risk_reduction)
        
        # Simulate modified ward data
        modified_data = copy.deepcopy(ward_data)
        for field in impact_model.get('affects', []):
            if field in modified_data:
                if field.endswith('_idx'):
                    # Reduce index values
                    modified_data[field] = max(0.1, modified_data[field] - (0.3 * intensity))
                elif field.endswith('_cases'):
                    # Reduce case counts
                    modified_data[field] = max(1, int(modified_data[field] * (1 - 0.3 * intensity)))
                elif field == 'hospital_capacity_score':
                    # Increase capacity
                    modified_data[field] = min(0.95, modified_data[field] + (0.2 * intensity))
        
        return {
            "intervention": impact_model.get('name'),
            "intensity": f"{intensity_percent}%",
            "original_risk": float(round(current_risk, 3)),
            "simulated_risk": float(round(new_risk, 3)),
            "risk_change": float(round(new_risk - current_risk, 3)),
            "risk_change_percent": f"{((new_risk - current_risk) / current_risk) * 100:.1f}%",
            "time_to_effect_days": impact_model.get('time_to_effect_days', 3),
            "modified_indicators": {
                k: v for k, v in modified_data.items() 
                if k in impact_model.get('affects', [])
            },
            "effectiveness": "HIGH" if risk_reduction > 0.2 else "MEDIUM" if risk_reduction > 0.1 else "LOW"
        }
    
    def simulate_delay(
        self,
        current_risk: float,
        delay_days: int,
        trend: str = "stable"
    ) -> Dict[str, Any]:
        """
        Simulate the impact of delaying action.
        """
        delay_model = self.INTERVENTION_IMPACTS["delay"]
        
        # Base increase per day
        base_increase = delay_model.get('risk_increase_per_day', 0.03)
        
        # Trend multiplier
        trend_multiplier = {
            "increasing": 1.5,
            "stable": 1.0,
            "decreasing": 0.5
        }.get(trend, 1.0)
        
        # Calculate compounding risk increase
        daily_increase = base_increase * trend_multiplier
        total_increase = min(
            delay_model.get('max_increase', 0.25),
            daily_increase * delay_days
        )
        
        new_risk = min(0.99, current_risk + total_increase)
        
        # Assess consequences
        if total_increase > 0.15:
            consequence = "SEVERE - Significant outbreak risk increase"
        elif total_increase > 0.08:
            consequence = "MODERATE - Noticeable risk escalation"
        else:
            consequence = "MINOR - Limited impact but monitoring needed"
        
        return {
            "delay_days": delay_days,
            "current_trend": trend,
            "original_risk": float(round(current_risk, 3)),
            "projected_risk": float(round(new_risk, 3)),
            "risk_increase": float(round(total_increase, 3)),
            "risk_increase_percent": f"+{total_increase * 100:.1f}%",
            "consequence_level": consequence,
            "recommendation": self._get_delay_recommendation(current_risk, new_risk, delay_days)
        }
    
    def _get_delay_recommendation(self, old_risk: float, new_risk: float, days: int) -> str:
        """Generate recommendation based on delay simulation."""
        if new_risk > 0.8:
            return f"⚠️ CRITICAL: {days}-day delay pushes risk to critical level. Immediate action strongly advised."
        elif new_risk > 0.6:
            return f"🔶 WARNING: Delay increases risk significantly. Consider deploying resources within {max(1, 3 - days)} days."
        elif new_risk > 0.4:
            return f"📋 CAUTION: Some risk increase expected. Maintain close monitoring during delay period."
        else:
            return f"✅ ACCEPTABLE: Risk remains manageable. Delay is feasible if higher priority areas exist."
    
    def simulate_multi_intervention(
        self,
        ward_data: Dict,
        current_risk: float,
        interventions: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Simulate multiple interventions together.
        
        Args:
            interventions: List of {"type": str, "intensity": int}
        """
        cumulative_risk = current_risk
        results = []
        
        for intervention in interventions:
            result = self.simulate_intervention(
                ward_data,
                cumulative_risk,
                intervention.get('type'),
                intervention.get('intensity', 50)
            )
            if 'error' not in result:
                cumulative_risk = result.get('simulated_risk', cumulative_risk)
                results.append(result)
        
        return {
            "original_risk": float(round(current_risk, 3)),
            "final_risk": float(round(cumulative_risk, 3)),
            "total_reduction": float(round(current_risk - cumulative_risk, 3)),
            "total_reduction_percent": f"{((current_risk - cumulative_risk) / current_risk) * 100:.1f}%",
            "intervention_results": results,
            "synergy_bonus": "Combined interventions have multiplicative effect" if len(results) > 1 else None
        }
    
    def simulate_resource_scenarios(
        self,
        wards: List[Dict],
        current_risks: Dict[int, float],
        available_resources: int,
        intervention_type: str
    ) -> List[Dict[str, Any]]:
        """
        Simulate different resource allocation scenarios across wards.
        Returns optimal allocation recommendation.
        """
        scenarios = []
        
        # Sort wards by current risk
        sorted_wards = sorted(
            wards,
            key=lambda w: current_risks.get(w.get('ward_id'), 0),
            reverse=True
        )
        
        # Scenario 1: Top-down allocation (highest risk first)
        top_down = []
        for i, ward in enumerate(sorted_wards[:available_resources]):
            ward_id = ward.get('ward_id')
            current = current_risks.get(ward_id, 0.5)
            sim = self.simulate_intervention(ward, current, intervention_type, 80)
            top_down.append({
                "ward_id": ward_id,
                "ward_name": ward.get('name'),
                "risk_reduction": sim.get('risk_change', 0)
            })
        
        scenarios.append({
            "strategy": "RISK_PRIORITY",
            "description": "Allocate to highest risk wards first",
            "allocations": top_down,
            "total_risk_reduction": sum(a['risk_reduction'] for a in top_down)
        })
        
        # Scenario 2: Population-weighted allocation
        pop_sorted = sorted(
            wards,
            key=lambda w: w.get('population', 0) * current_risks.get(w.get('ward_id'), 0),
            reverse=True
        )
        
        pop_weighted = []
        for ward in pop_sorted[:available_resources]:
            ward_id = ward.get('ward_id')
            current = current_risks.get(ward_id, 0.5)
            sim = self.simulate_intervention(ward, current, intervention_type, 80)
            pop_weighted.append({
                "ward_id": ward_id,
                "ward_name": ward.get('name'),
                "risk_reduction": sim.get('risk_change', 0),
                "population_covered": ward.get('population')
            })
        
        scenarios.append({
            "strategy": "POPULATION_RISK",
            "description": "Allocate based on population × risk",
            "allocations": pop_weighted,
            "total_risk_reduction": sum(a['risk_reduction'] for a in pop_weighted),
            "total_population_covered": sum(a.get('population_covered', 0) for a in pop_weighted)
        })
        
        # Find optimal
        best = max(scenarios, key=lambda s: abs(s.get('total_risk_reduction', 0)))
        best['recommended'] = True
        
        return scenarios
    
    def get_available_interventions(self) -> List[Dict]:
        """Return list of available interventions for UI."""
        return [
            {
                "id": key,
                "name": val.get('name'),
                "description": val.get('description'),
                "time_to_effect": val.get('time_to_effect_days', 'N/A'),
                "max_reduction": f"{val.get('max_reduction', 0) * 100:.0f}%" if 'max_reduction' in val else 'N/A'
            }
            for key, val in self.INTERVENTION_IMPACTS.items()
            if key != "delay"
        ]
