"""
MHIL - Micro-Health Intelligence Layer
Main FastAPI Application

Ward-level AI-assisted decision-support platform for municipal health governance
Berhampur City, Odisha | 37 Wards
"""

from fastapi import FastAPI, HTTPException, Query
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse
from pydantic import BaseModel
from typing import Dict, List, Any, Optional
import json
import os
from datetime import datetime

# ML Modules
from ml.risk_predictor import RiskPredictor, predict_all_wards
from ml.clustering import WardClusterer, cluster_all_wards
from ml.anomaly_detector import AnomalyDetector, detect_all_anomalies

# Decision Engine Modules
from engine.decision_engine import DecisionEngine, generate_policy_brief
from engine.simulator import WhatIfSimulator
from engine.resource_allocator import ResourceAllocator

# Initialize FastAPI
app = FastAPI(
    title="MHIL - Micro-Health Intelligence Layer",
    description="AI-powered ward-level health intelligence system for Berhampur City",
    version="1.0.0"
)

# Data storage
DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
FRONTEND_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "frontend")

# Initialize ML models
risk_predictor = RiskPredictor()
clusterer = WardClusterer(n_clusters=3)
anomaly_detector = AnomalyDetector()
decision_engine = DecisionEngine()
simulator = WhatIfSimulator()
resource_allocator = ResourceAllocator()

# Cache for ward data
ward_data_cache: Dict[int, Dict] = {}
citizen_reports_cache: List[Dict] = []
models_trained = False


# Pydantic Models
class CitizenReport(BaseModel):
    ward_id: int
    issue_type: str  # fever, water, garbage, air
    description: str
    count: int = 1


class SimulationRequest(BaseModel):
    ward_id: int
    intervention: str
    intensity_percent: int


class DelaySimulationRequest(BaseModel):
    ward_id: int
    delay_days: int


class ResourceAllocationRequest(BaseModel):
    resource_type: str
    available_units: int


# Helper Functions
def load_json_data(filename: str) -> Dict:
    """Load JSON data from file."""
    filepath = os.path.join(DATA_DIR, filename)
    with open(filepath, 'r') as f:
        return json.load(f)


def save_json_data(filename: str, data: Dict) -> None:
    """Save JSON data to file."""
    filepath = os.path.join(DATA_DIR, filename)
    with open(filepath, 'w') as f:
        json.dump(data, f, indent=2)


def merge_ward_data() -> List[Dict]:
    """Merge all ward datasets into unified ward objects."""
    demographics = load_json_data("demographics.json")["wards"]
    disease = load_json_data("disease_history.json")["wards"]
    environmental = load_json_data("environmental.json")["wards"]
    healthcare = load_json_data("healthcare_capacity.json")["wards"]
    
    # Create lookup dicts
    disease_map = {w["ward_id"]: w for w in disease}
    env_map = {w["ward_id"]: w for w in environmental}
    health_map = {w["ward_id"]: w for w in healthcare}
    
    merged = []
    for ward in demographics:
        ward_id = ward["ward_id"]
        unified = {**ward}
        
        if ward_id in disease_map:
            unified.update({k: v for k, v in disease_map[ward_id].items() if k != "ward_id"})
        if ward_id in env_map:
            unified.update({k: v for k, v in env_map[ward_id].items() if k != "ward_id"})
        if ward_id in health_map:
            unified.update({k: v for k, v in health_map[ward_id].items() if k != "ward_id"})
        
        # Add citizen reports count
        reports = [r for r in citizen_reports_cache if r.get("ward_id") == ward_id]
        unified["citizen_reports_count"] = sum(r.get("count", 1) for r in reports)
        
        merged.append(unified)
        ward_data_cache[ward_id] = unified
    
    return merged


def train_models():
    """Train all ML models on ward data."""
    global models_trained
    wards = merge_ward_data()
    risk_predictor.train(wards)
    clusterer.fit(wards)
    anomaly_detector.fit(wards)
    models_trained = True


def get_full_ward_assessment(ward_id: int) -> Dict:
    """Get complete assessment for a ward including all ML and decision outputs."""
    if not models_trained:
        train_models()
    
    ward = ward_data_cache.get(ward_id)
    if not ward:
        raise HTTPException(status_code=404, detail=f"Ward {ward_id} not found")
    
    # ML Predictions
    risk_pred = risk_predictor.predict_risk(ward)
    vulnerability = clusterer.predict_vulnerability(ward)
    anomaly = anomaly_detector.detect_anomaly(ward)
    
    # Decision Engine
    composite = decision_engine.compute_composite_risk(risk_pred, vulnerability, anomaly)
    time_to_outbreak = decision_engine.estimate_time_to_outbreak(
        composite["composite_score"],
        ward.get("trend_5yr", "stable"),
        anomaly.get("spikes_detected", [])
    )
    recommendations = decision_engine.recommend_actions(ward, composite, anomaly)
    root_cause = decision_engine.generate_root_cause_analysis(ward, risk_pred, anomaly)
    cost_impact = decision_engine.get_cost_impact_analysis(recommendations)
    
    return {
        "ward_id": ward_id,
        "ward_name": ward.get("name"),
        "ward_data": ward,
        "risk_prediction": risk_pred,
        "vulnerability": vulnerability,
        "anomaly_detection": anomaly,
        "composite_risk": composite,
        "time_to_outbreak": time_to_outbreak,
        "recommendations": recommendations,
        "root_cause_analysis": root_cause,
        "cost_impact_analysis": cost_impact
    }


# API Endpoints

@app.on_event("startup")
async def startup_event():
    """Initialize data and models on startup."""
    global citizen_reports_cache
    try:
        reports = load_json_data("citizen_reports.json")
        citizen_reports_cache = reports.get("reports", [])
    except:
        citizen_reports_cache = []
    train_models()


@app.get("/", response_class=HTMLResponse)
async def root():
    """Serve the main dashboard."""
    index_path = os.path.join(FRONTEND_DIR, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return HTMLResponse("<h1>MHIL - Micro-Health Intelligence Layer</h1><p>Frontend loading...</p>")


# Ward Data Endpoints
@app.get("/api/wards")
async def get_all_wards():
    """Get summary of all 37 wards with risk indicators."""
    if not models_trained:
        train_models()
    
    wards = list(ward_data_cache.values())
    summaries = []
    
    for ward in wards:
        ward_id = ward.get("ward_id")
        risk_pred = risk_predictor.predict_risk(ward)
        vulnerability = clusterer.predict_vulnerability(ward)
        anomaly = anomaly_detector.detect_anomaly(ward)
        composite = decision_engine.compute_composite_risk(risk_pred, vulnerability, anomaly)
        
        summaries.append({
            "ward_id": ward_id,
            "name": ward.get("name"),
            "population": ward.get("population"),
            "risk_score": composite.get("composite_score"),
            "risk_level": risk_pred.get("risk_level"),
            "priority": composite.get("priority"),
            "vulnerability": vulnerability.get("vulnerability_level"),
            "anomaly_warning": anomaly.get("warning_level"),
            "trend": ward.get("trend_5yr", "stable")
        })
    
    # Sort by risk score
    summaries.sort(key=lambda x: x.get("risk_score", 0), reverse=True)
    
    # Add rank
    for i, ward in enumerate(summaries):
        ward["rank"] = i + 1
    
    # Calculate city-wide stats
    high_risk = len([w for w in summaries if w.get("priority") in ["CRITICAL", "HIGH"]])
    medium_risk = len([w for w in summaries if w.get("priority") == "MEDIUM"])
    
    return {
        "total_wards": len(summaries),
        "high_risk_count": high_risk,
        "medium_risk_count": medium_risk,
        "low_risk_count": len(summaries) - high_risk - medium_risk,
        "wards": summaries,
        "last_updated": datetime.now().isoformat()
    }


@app.get("/api/wards/{ward_id}")
async def get_ward_detail(ward_id: int):
    """Get detailed information for a specific ward."""
    return get_full_ward_assessment(ward_id)


@app.get("/api/wards/{ward_id}/policy-brief")
async def get_ward_policy_brief(ward_id: int):
    """Generate one-click policy brief for a ward."""
    assessment = get_full_ward_assessment(ward_id)
    
    brief = generate_policy_brief(
        assessment["ward_data"],
        assessment["composite_risk"],
        assessment["recommendations"],
        assessment["time_to_outbreak"]
    )
    
    return {
        "ward_id": ward_id,
        "ward_name": assessment["ward_name"],
        "generated_at": datetime.now().isoformat(),
        "policy_brief": brief
    }


# Risk Analysis Endpoints
@app.get("/api/risk/analysis")
async def get_risk_analysis():
    """Get risk analysis for all wards."""
    if not models_trained:
        train_models()
    
    wards = list(ward_data_cache.values())
    all_predictions = predict_all_wards(risk_predictor, wards)
    all_clusters = cluster_all_wards(clusterer, wards)
    all_anomalies = detect_all_anomalies(anomaly_detector, wards)
    
    return {
        "risk_predictions": all_predictions,
        "vulnerability_clusters": all_clusters,
        "anomaly_detections": all_anomalies,
        "model_explanations": {
            "risk_model": risk_predictor.get_model_explanation(),
            "clustering_model": clusterer.get_cluster_summary(),
            "anomaly_model": anomaly_detector.get_model_explanation()
        }
    }


@app.get("/api/risk/prioritization")
async def get_prioritization():
    """Get ward prioritization ranking."""
    if not models_trained:
        train_models()
    
    assessments = []
    for ward_id in ward_data_cache.keys():
        assessment = get_full_ward_assessment(ward_id)
        assessments.append({
            "ward_id": ward_id,
            "ward_name": assessment["ward_name"],
            "composite_score": assessment["composite_risk"]["composite_score"],
            "priority": assessment["composite_risk"]["priority"],
            "urgency": assessment["composite_risk"]["urgency"],
            "time_to_outbreak": assessment["time_to_outbreak"]["estimated_days"],
            "vulnerability": assessment["vulnerability"]["vulnerability_level"]
        })
    
    ranked = decision_engine.rank_wards(assessments)
    
    return {
        "ranking": ranked,
        "critical_count": len([w for w in ranked if w["priority"] == "CRITICAL"]),
        "immediate_action_required": [w for w in ranked if w["urgency"] == "IMMEDIATE"]
    }


# Decision & Recommendation Endpoints
@app.get("/api/decisions/recommendations")
async def get_all_recommendations():
    """Get action recommendations for all wards."""
    if not models_trained:
        train_models()
    
    all_recommendations = []
    for ward_id in ward_data_cache.keys():
        assessment = get_full_ward_assessment(ward_id)
        all_recommendations.append({
            "ward_id": ward_id,
            "ward_name": assessment["ward_name"],
            "priority": assessment["composite_risk"]["priority"],
            "recommendations": assessment["recommendations"][:3]  # Top 3
        })
    
    # Sort by priority
    priority_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
    all_recommendations.sort(key=lambda x: priority_order.get(x["priority"], 4))
    
    return {"ward_recommendations": all_recommendations}


@app.get("/api/decisions/recommendations/{ward_id}")
async def get_ward_recommendations(ward_id: int):
    """Get detailed recommendations for a specific ward."""
    assessment = get_full_ward_assessment(ward_id)
    return {
        "ward_id": ward_id,
        "ward_name": assessment["ward_name"],
        "composite_risk": assessment["composite_risk"],
        "recommendations": assessment["recommendations"],
        "cost_impact_analysis": assessment["cost_impact_analysis"],
        "root_cause_analysis": assessment["root_cause_analysis"]
    }


# Simulation Endpoints
@app.post("/api/simulation/whatif")
async def simulate_intervention(request: SimulationRequest):
    """Simulate the impact of an intervention on a ward's risk."""
    ward = ward_data_cache.get(request.ward_id)
    if not ward:
        raise HTTPException(status_code=404, detail=f"Ward {request.ward_id} not found")
    
    assessment = get_full_ward_assessment(request.ward_id)
    current_risk = assessment["composite_risk"]["composite_score"]
    
    result = simulator.simulate_intervention(
        ward,
        current_risk,
        request.intervention,
        request.intensity_percent
    )
    
    result["ward_id"] = request.ward_id
    result["ward_name"] = ward.get("name")
    
    return result


@app.post("/api/simulation/delay")
async def simulate_delay(request: DelaySimulationRequest):
    """Simulate the impact of delaying action."""
    ward = ward_data_cache.get(request.ward_id)
    if not ward:
        raise HTTPException(status_code=404, detail=f"Ward {request.ward_id} not found")
    
    assessment = get_full_ward_assessment(request.ward_id)
    current_risk = assessment["composite_risk"]["composite_score"]
    trend = ward.get("trend_5yr", "stable")
    
    result = simulator.simulate_delay(current_risk, request.delay_days, trend)
    result["ward_id"] = request.ward_id
    result["ward_name"] = ward.get("name")
    
    return result


@app.get("/api/simulation/interventions")
async def get_available_interventions():
    """Get list of available interventions for simulation."""
    return {"interventions": simulator.get_available_interventions()}


# Resource Allocation Endpoints
@app.post("/api/resources/allocate")
async def allocate_resources(request: ResourceAllocationRequest):
    """Get optimal resource allocation across wards."""
    if not models_trained:
        train_models()
    
    wards = list(ward_data_cache.values())
    risks = {}
    
    for ward in wards:
        ward_id = ward.get("ward_id")
        assessment = get_full_ward_assessment(ward_id)
        risks[ward_id] = {
            "composite_score": assessment["composite_risk"]["composite_score"],
            "time_to_outbreak": assessment["time_to_outbreak"]
        }
    
    allocation = resource_allocator.allocate_resources(
        wards,
        risks,
        request.resource_type,
        request.available_units
    )
    
    return allocation


@app.get("/api/resources/requirements")
async def get_resource_requirements(target: str = Query("all_high_risk")):
    """Get resource requirements to cover target wards."""
    if not models_trained:
        train_models()
    
    wards = list(ward_data_cache.values())
    risks = {}
    
    for ward in wards:
        ward_id = ward.get("ward_id")
        assessment = get_full_ward_assessment(ward_id)
        risks[ward_id] = {
            "composite_score": assessment["composite_risk"]["composite_score"]
        }
    
    return resource_allocator.get_resource_requirements(wards, risks, target)


# Citizen Input Endpoints
@app.post("/api/citizen/report")
async def submit_citizen_report(report: CitizenReport):
    """Submit a citizen complaint/report that feeds into the risk model."""
    global citizen_reports_cache
    
    new_report = {
        "id": len(citizen_reports_cache) + 1,
        "ward_id": report.ward_id,
        "issue_type": report.issue_type,
        "description": report.description,
        "count": report.count,
        "timestamp": datetime.now().isoformat()
    }
    
    citizen_reports_cache.append(new_report)
    
    # Update data file
    try:
        save_json_data("citizen_reports.json", {"reports": citizen_reports_cache})
    except:
        pass  # Continue even if save fails
    
    # Retrain models to incorporate new data
    train_models()
    
    # Get updated risk for the ward
    assessment = get_full_ward_assessment(report.ward_id)
    
    return {
        "message": "Report submitted successfully",
        "report_id": new_report["id"],
        "ward_id": report.ward_id,
        "updated_risk": assessment["composite_risk"]["composite_score"],
        "impact_note": "Your report has been recorded and will influence risk assessment"
    }


@app.get("/api/citizen/reports")
async def get_citizen_reports(ward_id: Optional[int] = None):
    """Get citizen reports, optionally filtered by ward."""
    if ward_id:
        reports = [r for r in citizen_reports_cache if r.get("ward_id") == ward_id]
    else:
        reports = citizen_reports_cache
    
    return {
        "total_reports": len(reports),
        "reports": sorted(reports, key=lambda x: x.get("timestamp", ""), reverse=True)
    }


# Explainability Endpoints
@app.get("/api/explain/ward/{ward_id}")
async def explain_ward_risk(ward_id: int):
    """Get detailed explanation of a ward's risk factors."""
    assessment = get_full_ward_assessment(ward_id)
    
    return {
        "ward_id": ward_id,
        "ward_name": assessment["ward_name"],
        "risk_explanation": assessment["root_cause_analysis"],
        "feature_contributions": assessment["risk_prediction"]["feature_contributions"],
        "top_risk_factors": assessment["risk_prediction"]["top_risk_factors"],
        "vulnerability_factors": assessment["vulnerability"]["vulnerability_factors"],
        "anomaly_details": assessment["anomaly_detection"]
    }


@app.get("/api/explain/models")
async def explain_models():
    """Get explanation of all ML models used."""
    return {
        "risk_prediction_model": risk_predictor.get_model_explanation(),
        "clustering_model": clusterer.get_cluster_summary(),
        "anomaly_detection_model": anomaly_detector.get_model_explanation(),
        "system_overview": {
            "name": "MHIL - Micro-Health Intelligence Layer",
            "purpose": "AI-powered ward-level health intelligence for Berhampur City",
            "total_wards": 37,
            "decision_approach": "Composite risk scoring combining ML predictions, vulnerability clustering, and anomaly detection",
            "explainability_focus": "All decisions include reasoning traces and factor breakdowns"
        }
    }


# HTML Page Serving
@app.get("/")
async def read_root():
    """Serve the main dashboard."""
    return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))

@app.get("/{page_name}.html")
async def read_page(page_name: str):
    """Serve other HTML pages like citizen.html, simulation.html."""
    file_path = os.path.join(FRONTEND_DIR, f"{page_name}.html")
    if os.path.exists(file_path):
        return FileResponse(file_path)
    raise HTTPException(status_code=404, detail="Page not found")


# Static file serving for frontend
app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")
app.mount("/css", StaticFiles(directory=os.path.join(FRONTEND_DIR, "css")), name="css")
app.mount("/js", StaticFiles(directory=os.path.join(FRONTEND_DIR, "js")), name="js")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
