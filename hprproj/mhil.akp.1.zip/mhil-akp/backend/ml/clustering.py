"""
Ward Clustering Module - KMeans-based vulnerability classification
Clusters wards into High/Medium/Low vulnerability groups
"""

import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from typing import Dict, List, Any


class WardClusterer:
    """
    Unsupervised clustering of wards based on vulnerability factors.
    Uses KMeans to group wards into vulnerability categories.
    """
    
    def __init__(self, n_clusters: int = 3):
        self.n_clusters = n_clusters
        self.model = KMeans(
            n_clusters=n_clusters,
            random_state=42,
            n_init=10
        )
        self.scaler = StandardScaler()
        self.feature_names = [
            'population',
            'density',
            'age_60_plus_pct',
            'hospital_capacity_score',
            'garbage_backlog_idx',
            'water_stagnation_idx',
            'water_quality_idx'
        ]
        self.cluster_labels = {}  # Maps cluster ID to vulnerability level
        self.is_fitted = False
    
    def prepare_features(self, ward_data: Dict) -> np.ndarray:
        """Extract clustering features from ward data."""
        features = [
            ward_data.get('population', 10000),
            ward_data.get('density', 8000),
            ward_data.get('age_60_plus_pct', 15),
            ward_data.get('hospital_capacity_score', 0.6),
            ward_data.get('garbage_backlog_idx', 0.5),
            ward_data.get('water_stagnation_idx', 0.5),
            ward_data.get('water_quality_idx', 0.7)
        ]
        return np.array(features)
    
    def fit(self, all_wards_data: List[Dict]) -> None:
        """Fit the clustering model on all wards."""
        X = np.array([self.prepare_features(w) for w in all_wards_data])
        X_scaled = self.scaler.fit_transform(X)
        
        self.model.fit(X_scaled)
        self._assign_vulnerability_labels(X_scaled, all_wards_data)
        self.is_fitted = True
    
    def _assign_vulnerability_labels(self, X_scaled: np.ndarray, wards_data: List[Dict]) -> None:
        """
        Assign vulnerability labels to clusters based on cluster characteristics.
        Higher composite score = higher vulnerability.
        """
        cluster_scores = {}
        
        for cluster_id in range(self.n_clusters):
            cluster_mask = self.model.labels_ == cluster_id
            cluster_data = [w for i, w in enumerate(wards_data) if cluster_mask[i]]
            
            # Calculate vulnerability score for this cluster
            avg_density = np.mean([w.get('density', 8000) for w in cluster_data])
            avg_elderly = np.mean([w.get('age_60_plus_pct', 15) for w in cluster_data])
            avg_garbage = np.mean([w.get('garbage_backlog_idx', 0.5) for w in cluster_data])
            avg_capacity = np.mean([w.get('hospital_capacity_score', 0.6) for w in cluster_data])
            
            # Vulnerability score: high density, high elderly, high garbage, low capacity = vulnerable
            score = (
                (avg_density / 15000) * 0.25 +
                (avg_elderly / 25) * 0.25 +
                avg_garbage * 0.25 +
                (1 - avg_capacity) * 0.25
            )
            cluster_scores[cluster_id] = score
        
        # Sort clusters by score and assign labels
        sorted_clusters = sorted(cluster_scores.items(), key=lambda x: x[1], reverse=True)
        vulnerability_levels = ["HIGH", "MEDIUM", "LOW"]
        
        for i, (cluster_id, _) in enumerate(sorted_clusters):
            self.cluster_labels[cluster_id] = vulnerability_levels[min(i, 2)]
    
    def predict_vulnerability(self, ward_data: Dict) -> Dict[str, Any]:
        """Predict vulnerability class for a single ward."""
        if not self.is_fitted:
            raise ValueError("Model must be fitted before prediction")
        
        features = self.prepare_features(ward_data).reshape(1, -1)
        features_scaled = self.scaler.transform(features)
        
        cluster_id = self.model.predict(features_scaled)[0]
        vulnerability = self.cluster_labels.get(cluster_id, "MEDIUM")
        
        # Calculate distance to cluster center (for confidence)
        center = self.model.cluster_centers_[cluster_id]
        distance = np.linalg.norm(features_scaled[0] - center)
        confidence = max(0, 1 - (distance / 5))  # Normalize distance to confidence
        
        return {
            "cluster_id": int(cluster_id),
            "vulnerability_level": vulnerability,
            "confidence": float(round(confidence, 3)),
            "vulnerability_factors": self._get_vulnerability_factors(ward_data)
        }
    
    def _get_vulnerability_factors(self, ward_data: Dict) -> List[Dict]:
        """Identify key vulnerability factors for a ward."""
        factors = []
        
        if ward_data.get('density', 0) > 10000:
            factors.append({
                "factor": "High Population Density",
                "severity": "HIGH",
                "value": ward_data.get('density')
            })
        
        if ward_data.get('age_60_plus_pct', 0) > 18:
            factors.append({
                "factor": "High Elderly Population",
                "severity": "MEDIUM",
                "value": f"{ward_data.get('age_60_plus_pct')}%"
            })
        
        if ward_data.get('hospital_capacity_score', 1) < 0.5:
            factors.append({
                "factor": "Limited Healthcare Capacity",
                "severity": "HIGH",
                "value": ward_data.get('hospital_capacity_score')
            })
        
        if ward_data.get('garbage_backlog_idx', 0) > 0.7:
            factors.append({
                "factor": "High Garbage Backlog",
                "severity": "HIGH",
                "value": ward_data.get('garbage_backlog_idx')
            })
        
        if ward_data.get('water_stagnation_idx', 0) > 0.6:
            factors.append({
                "factor": "Water Stagnation Issues",
                "severity": "HIGH",
                "value": ward_data.get('water_stagnation_idx')
            })
        
        return factors
    
    def get_cluster_summary(self) -> Dict:
        """Return summary of clusters for explanation."""
        return {
            "n_clusters": self.n_clusters,
            "cluster_labels": self.cluster_labels,
            "features_used": self.feature_names,
            "method": "K-Means Clustering",
            "interpretation": "Wards are grouped by structural vulnerability factors"
        }


def cluster_all_wards(clusterer: WardClusterer, wards_data: List[Dict]) -> List[Dict]:
    """Predict vulnerability for all wards."""
    results = []
    for ward in wards_data:
        prediction = clusterer.predict_vulnerability(ward)
        prediction['ward_id'] = ward.get('ward_id')
        prediction['ward_name'] = ward.get('name', f"Ward {ward.get('ward_id')}")
        results.append(prediction)
    return results
