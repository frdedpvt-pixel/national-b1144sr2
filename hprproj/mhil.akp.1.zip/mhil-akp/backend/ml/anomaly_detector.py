"""
Anomaly Detection Module - Detect abnormal disease spikes
Uses Isolation Forest and statistical methods for early warning signals
"""

import numpy as np
from sklearn.ensemble import IsolationForest
from typing import Dict, List, Any
from datetime import datetime


class AnomalyDetector:
    """
    Detects anomalous disease patterns using Isolation Forest.
    Flags wards with abnormal spikes compared to historical trends.
    """
    
    def __init__(self, contamination: float = 0.15):
        self.model = IsolationForest(
            contamination=contamination,
            random_state=42,
            n_estimators=50
        )
        self.feature_names = [
            'fever_weekly',
            'dengue_cases',
            'waterborne_cases',
            'respiratory_cases'
        ]
        self.historical_means = {}
        self.historical_stds = {}
        self.is_fitted = False
    
    def prepare_features(self, ward_data: Dict) -> np.ndarray:
        """Extract disease-related features for anomaly detection."""
        features = [
            ward_data.get('fever_weekly', 0),
            ward_data.get('dengue_cases', 0),
            ward_data.get('waterborne_cases', 0),
            ward_data.get('respiratory_cases', 0)
        ]
        return np.array(features)
    
    def fit(self, all_wards_data: List[Dict]) -> None:
        """Fit the anomaly detection model and compute historical baselines."""
        X = np.array([self.prepare_features(w) for w in all_wards_data])
        
        # Compute historical statistics for each feature
        for i, name in enumerate(self.feature_names):
            self.historical_means[name] = np.mean(X[:, i])
            self.historical_stds[name] = np.std(X[:, i]) + 0.001  # Avoid division by zero
        
        self.model.fit(X)
        self.is_fitted = True
    
    def detect_anomaly(self, ward_data: Dict) -> Dict[str, Any]:
        """
        Detect if a ward's disease patterns are anomalous.
        Returns anomaly flag, severity, and specific spikes detected.
        """
        if not self.is_fitted:
            raise ValueError("Model must be fitted before detection")
        
        features = self.prepare_features(ward_data).reshape(1, -1)
        
        # Isolation Forest prediction (-1 = anomaly, 1 = normal)
        prediction = self.model.predict(features)[0]
        anomaly_score = -self.model.score_samples(features)[0]  # Higher = more anomalous
        
        is_anomaly = bool(prediction == -1)
        
        # Identify specific anomalous features using z-score
        spikes = []
        z_scores = {}
        
        for i, name in enumerate(self.feature_names):
            value = float(features[0][i])
            mean = float(self.historical_means[name])
            std = float(self.historical_stds[name])
            z = (value - mean) / std
            z_scores[name] = float(round(z, 2))
            
            if z > 2.0:
                severity = "CRITICAL" if z > 3.0 else "HIGH" if z > 2.5 else "MODERATE"
                spikes.append({
                    "indicator": self._get_indicator_label(name),
                    "current_value": value,
                    "expected_value": round(mean, 1),
                    "deviation": f"+{round((value/mean - 1) * 100)}%" if mean > 0 else "N/A",
                    "severity": severity,
                    "z_score": float(round(z, 2))
                })
        
        # Determine overall warning level
        if len(spikes) >= 3 or any(s['severity'] == 'CRITICAL' for s in spikes):
            warning_level = "RED"
        elif len(spikes) >= 2 or any(s['severity'] == 'HIGH' for s in spikes):
            warning_level = "ORANGE"
        elif len(spikes) >= 1:
            warning_level = "YELLOW"
        else:
            warning_level = "GREEN"
        
        return {
            "is_anomaly": is_anomaly,
            "anomaly_score": float(round(anomaly_score, 3)),
            "warning_level": warning_level,
            "spikes_detected": spikes,
            "z_scores": z_scores,
            "early_warning": self._generate_warning_message(spikes, ward_data)
        }
    
    def _get_indicator_label(self, name: str) -> str:
        """Convert feature name to human-readable label."""
        labels = {
            'fever_weekly': 'Weekly Fever Cases',
            'dengue_cases': 'Dengue/Vector-borne Cases',
            'waterborne_cases': 'Waterborne Disease Cases',
            'respiratory_cases': 'Respiratory Cases'
        }
        return labels.get(name, name)
    
    def _generate_warning_message(self, spikes: List[Dict], ward_data: Dict) -> str:
        """Generate human-readable early warning message."""
        if not spikes:
            return "No abnormal disease patterns detected. Continue routine monitoring."
        
        ward_name = ward_data.get('name', f"Ward {ward_data.get('ward_id')}")
        spike_names = [s['indicator'] for s in spikes]
        
        if len(spikes) >= 3:
            return f"⚠️ CRITICAL ALERT: Multiple disease indicators spiking in {ward_name}. Immediate investigation required for: {', '.join(spike_names)}."
        elif len(spikes) == 2:
            return f"🔶 HIGH ALERT: Abnormal increase in {spike_names[0]} and {spike_names[1]} in {ward_name}. Recommend field verification within 24 hours."
        else:
            return f"⚡ MODERATE ALERT: Elevated {spike_names[0]} detected in {ward_name}. Monitor closely for next 48-72 hours."
    
    def get_model_explanation(self) -> Dict:
        """Return model explanation for transparency."""
        return {
            "model_type": "Isolation Forest + Z-Score Analysis",
            "contamination_rate": 0.15,
            "features_monitored": self.feature_names,
            "baseline_means": {k: round(v, 2) for k, v in self.historical_means.items()},
            "interpretation": "Detects wards with disease patterns significantly deviating from city baseline"
        }


def detect_all_anomalies(detector: AnomalyDetector, wards_data: List[Dict]) -> List[Dict]:
    """Detect anomalies for all wards."""
    results = []
    for ward in wards_data:
        detection = detector.detect_anomaly(ward)
        detection['ward_id'] = ward.get('ward_id')
        detection['ward_name'] = ward.get('name', f"Ward {ward.get('ward_id')}")
        results.append(detection)
    return results
