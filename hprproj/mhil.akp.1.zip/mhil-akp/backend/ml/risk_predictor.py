"""
Risk Prediction Module - RandomForest-based outbreak risk prediction
Uses multi-feature learning for ward-level disease outbreak probability
"""

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from typing import Dict, List, Tuple, Any
import json


class RiskPredictor:
    """
    ML-based risk predictor using RandomForest for disease outbreak prediction.
    Provides interpretable results with feature importance.
    """
    
    def __init__(self):
        self.model = RandomForestClassifier(
            n_estimators=50,
            max_depth=8,
            random_state=42,
            min_samples_split=3,
            min_samples_leaf=2
        )
        self.scaler = StandardScaler()
        self.feature_names = [
            'fever_weekly',
            'dengue_cases',
            'waterborne_cases',
            'respiratory_cases',
            'aqi',
            'garbage_backlog_idx',
            'water_stagnation_idx',
            'water_quality_idx',
            'population_density',
            'hospital_capacity_score',
            'citizen_reports_count'
        ]
        self.is_trained = False
    
    def prepare_features(self, ward_data: Dict) -> np.ndarray:
        """Extract features from ward data dictionary."""
        features = [
            ward_data.get('fever_weekly', 0),
            ward_data.get('dengue_cases', 0),
            ward_data.get('waterborne_cases', 0),
            ward_data.get('respiratory_cases', 0),
            ward_data.get('aqi', 100),
            ward_data.get('garbage_backlog_idx', 0.5),
            ward_data.get('water_stagnation_idx', 0.5),
            ward_data.get('water_quality_idx', 0.7),
            ward_data.get('density', 8000),
            ward_data.get('hospital_capacity_score', 0.6),
            ward_data.get('citizen_reports_count', 0)
        ]
        return np.array(features).reshape(1, -1)
    
    def generate_training_data(self, all_wards_data: List[Dict]) -> Tuple[np.ndarray, np.ndarray]:
        """
        Generate synthetic training labels based on data patterns.
        High-risk label (1) if multiple risk indicators exceed thresholds.
        """
        X = []
        y = []
        
        for ward in all_wards_data:
            features = self.prepare_features(ward).flatten()
            X.append(features)
            
            # Generate target based on realistic disease outbreak patterns
            risk_score = 0
            if ward.get('fever_weekly', 0) > 50:
                risk_score += 0.25
            if ward.get('dengue_cases', 0) > 15:
                risk_score += 0.25
            if ward.get('garbage_backlog_idx', 0) > 0.6:
                risk_score += 0.15
            if ward.get('water_stagnation_idx', 0) > 0.5:
                risk_score += 0.15
            if ward.get('aqi', 100) > 150:
                risk_score += 0.10
            if ward.get('hospital_capacity_score', 1) < 0.55:
                risk_score += 0.10
            
            # Binary classification: high risk if score > 0.5
            y.append(1 if risk_score > 0.5 else 0)
        
        return np.array(X), np.array(y)
    
    def train(self, all_wards_data: List[Dict]) -> None:
        """Train the model on ward data."""
        X, y = self.generate_training_data(all_wards_data)
        
        # Ensure we have both classes
        if len(np.unique(y)) < 2:
            # Add synthetic samples to ensure both classes exist
            y[0] = 1
            y[-1] = 0
        
        X_scaled = self.scaler.fit_transform(X)
        self.model.fit(X_scaled, y)
        self.is_trained = True
    
    def predict_risk(self, ward_data: Dict) -> Dict[str, Any]:
        """
        Predict outbreak risk for a single ward.
        Returns probability, confidence, and feature contributions.
        """
        if not self.is_trained:
            raise ValueError("Model must be trained before prediction")
        
        features = self.prepare_features(ward_data)
        features_scaled = self.scaler.transform(features)
        
        # Get probability prediction
        proba = self.model.predict_proba(features_scaled)[0]
        risk_probability = proba[1] if len(proba) > 1 else proba[0]
        
        # Calculate confidence based on probability distance from 0.5
        confidence = abs(risk_probability - 0.5) * 2
        
        # Get feature importance
        importance = self.model.feature_importances_
        feature_contributions = {}
        for i, name in enumerate(self.feature_names):
            feature_contributions[name] = float(round(importance[i] * 100, 2))
        
        # Determine risk level
        if risk_probability >= 0.7:
            risk_level = "HIGH"
        elif risk_probability >= 0.4:
            risk_level = "MEDIUM"
        else:
            risk_level = "LOW"
        
        return {
            "risk_probability": float(round(risk_probability, 3)),
            "confidence": float(round(confidence, 3)),
            "risk_level": risk_level,
            "feature_contributions": feature_contributions,
            "top_risk_factors": self._get_top_factors(feature_contributions, 3)
        }
    
    def _get_top_factors(self, contributions: Dict, n: int) -> List[Dict]:
        """Get top N contributing factors."""
        sorted_factors = sorted(
            contributions.items(),
            key=lambda x: x[1],
            reverse=True
        )[:n]
        
        factor_labels = {
            'fever_weekly': 'Weekly Fever Cases',
            'dengue_cases': 'Dengue Cases',
            'waterborne_cases': 'Waterborne Disease Cases',
            'respiratory_cases': 'Respiratory Cases',
            'aqi': 'Air Quality Index',
            'garbage_backlog_idx': 'Garbage Backlog',
            'water_stagnation_idx': 'Water Stagnation',
            'water_quality_idx': 'Water Quality',
            'population_density': 'Population Density',
            'hospital_capacity_score': 'Healthcare Capacity',
            'citizen_reports_count': 'Citizen Reports'
        }
        
        return [
            {"factor": factor_labels.get(f, f), "contribution_pct": c}
            for f, c in sorted_factors
        ]
    
    def get_model_explanation(self) -> Dict:
        """Return model explanation for transparency."""
        return {
            "model_type": "Random Forest Classifier",
            "n_estimators": 50,
            "features_used": len(self.feature_names),
            "feature_list": self.feature_names,
            "interpretation": "Higher probability indicates greater risk of disease outbreak in the next 7-14 days"
        }


def predict_all_wards(predictor: RiskPredictor, wards_data: List[Dict]) -> List[Dict]:
    """Predict risk for all wards."""
    results = []
    for ward in wards_data:
        prediction = predictor.predict_risk(ward)
        prediction['ward_id'] = ward.get('ward_id')
        prediction['ward_name'] = ward.get('name', f"Ward {ward.get('ward_id')}")
        results.append(prediction)
    return results
