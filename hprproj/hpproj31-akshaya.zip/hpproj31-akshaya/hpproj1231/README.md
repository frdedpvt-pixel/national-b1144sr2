# 🧠 Adaptive Study Assistant

An intelligent study recommendation system that demonstrates **real decision-making under partial information** using online learning and belief state estimation.

## 🎯 Project Overview

This hackathon project implements a decision engine that:
- ✅ Operates with incomplete, noisy, and missing data
- ✅ Estimates hidden internal user states (confidence, intent, preference)
- ✅ Adapts decisions over time through online updates
- ✅ Explains every decision transparently
- ✅ Admits uncertainty and limitations honestly

**No deep learning. No pre-training. Pure decision theory and online learning.**

## 🏗️ System Architecture

### Decision Loop
```
Observe → Estimate State → Score Actions → Choose → Get Feedback → Update Beliefs
```

### Core Components

#### Backend (`/backend`)
- **Belief State Manager** - Persistent user state estimation
- **Update Logic** - Implements exact belief update formula
- **Decision Logic** - Multi-criteria task scoring and ranking
- **Time Decay** - Exponential decay of old information
- **API Routes** - REST endpoints for all operations

#### Frontend (`/frontend`)
- **User Interaction** - Record study sessions with optional data
- **Recommendation Output** - Display AI-recommended tasks
- **Explanation Panel** - Transparent decision logic view
- **Learning History** - System performance over time

## 🧮 Core Math

### Belief Update Formula (EXACT)
```javascript
error = observed_score - belief_score
belief_score += learning_rate × confidence × error × decay
```

This formula is implemented **exactly as specified** in `backend/engine/updateLogic.js`.

## 🚀 Quick Start

### Prerequisites
- Node.js 16+ 
- npm

### Installation

1. **Clone/navigate to project**
```bash
cd hpproj1231
```

2. **Install backend dependencies**
```bash
cd backend
npm install
```

3. **Install frontend dependencies**
```bash
cd ../frontend
npm install
```

### Running the Application

**Terminal 1 - Backend:**
```bash
cd backend
npm run dev
```
Backend runs on `http://localhost:5000`

**Terminal 2 - Frontend:**
```bash
cd frontend
npm run dev
```
Frontend runs on `http://localhost:5173`

Open `http://localhost:5173` in your browser.

## 📁 Project Structure

```
hpproj1231/
├── backend/
│   ├── engine/
│   │   ├── beliefState.js      # State management & persistence
│   │   ├── updateLogic.js      # Exact belief update formula
│   │   ├── decisionLogic.js    # Action scoring & ranking
│   │   └── decay.js            # Time-based decay
│   ├── routes/
│   │   ├── interaction.js      # Record interactions
│   │   ├── recommendation.js   # Get recommendations
│   │   └── state.js            # State & explanations
│   ├── data/
│   │   └── data.json           # Persistent storage
│   └── server.js               # Express server
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── UserInteraction.jsx      # Interaction form
│   │   │   ├── RecommendationOutput.jsx # Task display
│   │   │   ├── ExplanationPanel.jsx     # Decision logic
│   │   │   └── LearningHistory.jsx      # Metrics & trends
│   │   ├── services/
│   │   │   └── api.js          # API client
│   │   ├── App.jsx             # Main app
│   │   ├── main.jsx            # Entry point
│   │   └── index.css           # Styling
│   └── index.html
└── README.md
```

## ✨ Features

### ✅ All 10 Required Features Implemented

1. **Internal State Estimation** - Confidence, intent, preference estimated from behavior
2. **Partial/Noisy Input Handling** - All fields optional, graceful fallbacks
3. **Time-Based Logic** - Exponential decay reduces old data influence
4. **Adaptive Recommendations** - Scoring weights adapt based on outcomes
5. **Decision Explanations** - Complete transparency into reasoning
6. **Extensive AI** - Scoring, moving averages, confidence tracking, time decay
7. **Learning Over Time** - Performance metrics tracked and visualized
8. **Offline-Friendly** - JSON persistence, local caching
9. **Failure Awareness** - Explicit uncertainty flags and warnings
10. **Minimal UI** - Clean, functional interface focused on reasoning clarity

## 🎮 Usage Flow

### 1. Record Study Sessions
- Select task (optional)
- Enter duration (optional)
- Mark completion (optional)
- Provide feedback: easy/okay/hard (optional)

**All fields are optional** - system works with whatever data you provide.

### 2. Get Recommendations
- System scores all available tasks
- Shows top recommendation with explanation
- Displays confidence level and warnings
- Alternative suggestions provided

### 3. View Decision Logic
- See inputs used
- View estimated internal states
- Understand scoring criteria
- Identify uncertainties and limitations

### 4. Track Learning
- Monitor performance trends
- View completion rates
- See recommendation accuracy
- Observe belief state evolution

## 🧪 Testing the System

### Cold Start Test
1. Reset all data
2. Get recommendation - should show low confidence warnings
3. Verify default assumptions

### Learning Test
1. Record 10 interactions with consistent patterns
2. Observe belief state changes
3. Verify recommendations adapt

### Partial Data Test
1. Submit interaction with only 1-2 fields
2. Verify no errors
3. Check explanation shows appropriate uncertainty

### Time Decay Test
1. Record several interactions
2. Wait or modify timestamps
3. Verify older data has less influence

## 🔧 API Endpoints

### Interactions
- `POST /api/interaction/record` - Record interaction
- `GET /api/interaction/history` - Get all interactions
- `DELETE /api/interaction/reset` - Reset all data

### Recommendations
- `GET /api/recommendation/next` - Get next task
- `POST /api/recommendation/feedback` - Record outcome

### State
- `GET /api/state/current` - Get belief state
- `GET /api/state/explanation` - Get detailed explanation
- `GET /api/state/metrics` - Get learning metrics

## 🎓 Hackathon Judge Guide

### What Makes This System Intelligent?

1. **Real Decision-Making** - Not predetermined paths, actual scoring and selection
2. **Uncertainty Handling** - Explicit confidence levels and honest limitations
3. **Online Learning** - No training phase, learns from every interaction
4. **Transparent Logic** - Every decision is trace-able and explainable
5. **Graceful Degradation** - Works with minimal data, admits when unsure

### Tracing a Decision

1. Open **Explanation Panel**
2. See inputs used (interaction count, data quality)
3. View estimated states (confidence, intent, preference)
4. Review raw belief values
5. Check recent interactions that influenced beliefs
6. Read uncertainties and warnings

### Verifying Online Learning

1. Check `backend/engine/updateLogic.js` line 24-29 for exact formula
2. Record interactions and watch metrics change
3. Observe trend indicators (improving/declining/stable)
4. Note acceptance rate for recommendations

## 🚫 What This System Does NOT Use

- ❌ Deep learning
- ❌ Heavy ML libraries (TensorFlow, PyTorch, etc.)
- ❌ Pre-trained models
- ❌ Training phases
- ❌ Hard-coded decision trees
- ❌ Magic or black boxes

## 📊 Tech Stack

- **Frontend:** React 18 + Vite
- **Backend:** Node.js + Express
- **Storage:** JSON file persistence
- **Styling:** Vanilla CSS with glassmorphism
- **Dependencies:** Minimal (express, cors, body-parser, react, react-dom)

## 🎯 Design Principles

1. **Intelligence through belief updates, not complexity**
2. **Honesty over impressive-sounding claims**
3. **Clarity over polish**
4. **Function over form**
5. **Traceable over magical**

## 📝 License

MIT - Built for hackathon demonstration

---

**Built with discipline. Demonstrates real intelligence.**
