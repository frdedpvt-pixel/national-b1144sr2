const fs = require('fs').promises;
const path = require('path');

const DATA_FILE = path.join(__dirname, '../data/data.json');

/**
 * BELIEF STATE MANAGER
 * Manages persistent belief state representing estimated internal user states
 * 
 * Internal States:
 * - confidence: 0-1 numeric score (Low/Medium/High)
 * - intent: exploring/deciding/idle probabilities
 * - preference: visual/textBased probabilities
 */

class BeliefStateManager {
    constructor() {
        this.state = null;
    }

    /**
     * Load belief state from persistent storage
     */
    async load() {
        try {
            const data = await fs.readFile(DATA_FILE, 'utf8');
            const parsed = JSON.parse(data);
            this.state = parsed.beliefState;
            return this.state;
        } catch (error) {
            console.error('Error loading belief state:', error);
            // Return default state on error
            return this.getDefaultState();
        }
    }

    /**
     * Get default belief state (cold start)
     */
    getDefaultState() {
        return {
            confidence: 0.5,  // Start with medium uncertainty
            intent: {
                exploring: 0.6,  // Assume user is exploring initially
                deciding: 0.3,
                idle: 0.1
            },
            preference: {
                visual: 0.5,     // No preference yet
                textBased: 0.5
            }
        };
    }

    /**
     * Get current belief state
     */
    async getCurrentState() {
        if (!this.state) {
            await this.load();
        }
        return this.state;
    }

    /**
     * Update belief state with new values
     * @param {Object} updates - Partial or full state updates
     */
    async updateState(updates) {
        if (!this.state) {
            await this.load();
        }

        // Deep merge updates
        this.state = {
            ...this.state,
            ...updates,
            intent: { ...this.state.intent, ...(updates.intent || {}) },
            preference: { ...this.state.preference, ...(updates.preference || {}) }
        };

        // Persist to file
        await this.persist();
        return this.state;
    }

    /**
     * Persist belief state to JSON file
     */
    async persist() {
        try {
            const data = await fs.readFile(DATA_FILE, 'utf8');
            const parsed = JSON.parse(data);
            parsed.beliefState = this.state;
            await fs.writeFile(DATA_FILE, JSON.stringify(parsed, null, 2));
        } catch (error) {
            console.error('Error persisting belief state:', error);
            throw error;
        }
    }

    /**
     * Get confidence level as human-readable string
     */
    getConfidenceLevel() {
        const conf = this.state.confidence;
        if (conf < 0.3) return 'Low';
        if (conf < 0.7) return 'Medium';
        return 'High';
    }

    /**
     * Get dominant intent
     */
    getDominantIntent() {
        const intents = this.state.intent;
        return Object.keys(intents).reduce((a, b) =>
            intents[a] > intents[b] ? a : b
        );
    }

    /**
     * Get dominant preference
     */
    getDominantPreference() {
        const prefs = this.state.preference;
        return Object.keys(prefs).reduce((a, b) =>
            prefs[a] > prefs[b] ? a : b
        );
    }
}

module.exports = new BeliefStateManager();
