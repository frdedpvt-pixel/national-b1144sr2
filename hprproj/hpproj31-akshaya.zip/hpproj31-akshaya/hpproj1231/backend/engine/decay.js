/**
 * TIME DECAY MODULE
 * Reduces influence of older interactions using exponential decay
 * 
 * Older data should have less impact on current beliefs
 */

// Decay rate: how quickly old information loses influence
// Higher value = faster decay
const DECAY_RATE = 0.1;  // Per day

/**
 * Calculate time decay factor
 * @param {Date} timestamp - When the interaction occurred
 * @returns {number} Decay factor between 0 and 1
 */
function calculateDecay(timestamp) {
    if (!timestamp) {
        // Unknown timestamp = recent assumption
        return 1.0;
    }

    const now = new Date();
    const interactionTime = new Date(timestamp);

    // Calculate age in days
    const ageInMs = now - interactionTime;
    const ageInDays = ageInMs / (1000 * 60 * 60 * 24);

    // Exponential decay: e^(-decay_rate * age)
    const decayFactor = Math.exp(-DECAY_RATE * ageInDays);

    return Math.max(0.1, decayFactor);  // Minimum 10% influence
}

/**
 * Apply decay to a list of interactions
 * Returns each interaction with its decay weight
 */
function applyDecayToHistory(interactions) {
    return interactions.map(interaction => ({
        ...interaction,
        decayWeight: calculateDecay(interaction.timestamp)
    }));
}

/**
 * Calculate weighted average with decay
 */
function weightedAverage(values, timestamps) {
    if (values.length === 0) return 0;

    let weightedSum = 0;
    let totalWeight = 0;

    for (let i = 0; i < values.length; i++) {
        const weight = calculateDecay(timestamps[i]);
        weightedSum += values[i] * weight;
        totalWeight += weight;
    }

    return totalWeight > 0 ? weightedSum / totalWeight : 0;
}

module.exports = {
    calculateDecay,
    applyDecayToHistory,
    weightedAverage,
    DECAY_RATE
};
