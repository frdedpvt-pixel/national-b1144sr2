const { calculateDecay } = require('./decay');

/**
 * UPDATE LOGIC MODULE
 * Implements the EXACT belief update formula (NON-NEGOTIABLE)
 * 
 * Formula:
 * error = observed_score - belief_score
 * belief_score += learning_rate × confidence × error × decay
 * 
 * This is online learning - updates happen after each observation
 */

// Learning rate: controls how quickly beliefs adapt
const BASE_LEARNING_RATE = 0.15;

/**
 * CORE BELIEF UPDATE FUNCTION
 * Implements the exact formula specified
 * 
 * @param {number} currentBelief - Current belief score (0-1)
 * @param {number} observation - Observed score from interaction (0-1)
 * @param {number} confidence - Confidence in the observation (0-1)
 * @param {number} learningRate - How fast to adapt (0-1)
 * @param {number} decay - Time decay factor (0-1)
 * @returns {number} Updated belief score
 */
function updateBelief(currentBelief, observation, confidence, learningRate, decay) {
    // EXACT FORMULA - DO NOT MODIFY
    const error = observation - currentBelief;
    const update = learningRate * confidence * error * decay;
    const newBelief = currentBelief + update;

    // Clamp to [0, 1] range
    return Math.max(0, Math.min(1, newBelief));
}

/**
 * Convert raw interaction to normalized observation score
 * This is the "scoring function" that maps interactions to 0-1
 * 
 * Handles partial/missing data gracefully
 */
function calculateObservationScore(interaction) {
    let score = 0.5;  // Default neutral score
    let confidence = 0.3;  // Low confidence by default

    const signals = [];

    // Signal 1: Completion status
    if (interaction.completed !== undefined) {
        signals.push(interaction.completed ? 1.0 : 0.2);
        confidence += 0.2;
    }

    // Signal 2: Feedback (easy=0.3, okay=0.6, hard=0.9)
    if (interaction.feedback) {
        const feedbackMap = { easy: 0.3, okay: 0.6, hard: 0.9 };
        signals.push(feedbackMap[interaction.feedback] || 0.5);
        confidence += 0.3;
    }

    // Signal 3: Time spent (normalize to 0-1)
    if (interaction.duration !== undefined && interaction.duration > 0) {
        // Assume 30 min is "good" engagement
        const normalizedTime = Math.min(interaction.duration / 1800, 1.0);
        signals.push(normalizedTime);
        confidence += 0.2;
    }

    // Average signals if we have any
    if (signals.length > 0) {
        score = signals.reduce((a, b) => a + b, 0) / signals.length;
    }

    // Clamp confidence to [0, 1]
    confidence = Math.min(confidence, 1.0);

    return { score, confidence };
}

/**
 * Calculate moving average of recent observations
 * Smooths out noise in the data
 */
function calculateMovingAverage(recentScores, windowSize = 5) {
    if (recentScores.length === 0) return 0.5;

    const window = recentScores.slice(-windowSize);
    const sum = window.reduce((a, b) => a + b, 0);
    return sum / window.length;
}

/**
 * Estimate confidence in current belief based on data quality
 * More data + consistency = higher confidence
 */
function estimateBeliefConfidence(interactionHistory) {
    if (interactionHistory.length === 0) {
        return 0.3;  // Low confidence with no data
    }

    // Factor 1: Amount of data (more = better)
    const dataFactor = Math.min(interactionHistory.length / 20, 1.0);

    // Factor 2: Recency (recent interactions = higher confidence)
    const recentCount = interactionHistory.filter(i => {
        const age = Date.now() - new Date(i.timestamp).getTime();
        return age < 7 * 24 * 60 * 60 * 1000;  // Last 7 days
    }).length;
    const recencyFactor = Math.min(recentCount / 10, 1.0);

    // Factor 3: Consistency (low variance = higher confidence)
    const scores = interactionHistory.map(i => i.observedScore || 0.5);
    const variance = calculateVariance(scores);
    const consistencyFactor = 1 - Math.min(variance, 1.0);

    // Weighted combination
    const confidence = 0.3 + (
        0.3 * dataFactor +
        0.2 * recencyFactor +
        0.2 * consistencyFactor
    );

    return Math.min(confidence, 1.0);
}

/**
 * Calculate variance of values
 */
function calculateVariance(values) {
    if (values.length === 0) return 0;

    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const squaredDiffs = values.map(v => Math.pow(v - mean, 2));
    return squaredDiffs.reduce((a, b) => a + b, 0) / values.length;
}

/**
 * Update internal state estimates from interaction
 * Returns updated state components
 */
function updateInternalStates(currentState, interaction, history) {
    const updates = {};

    // Calculate observation and confidence
    const { score: obsScore, confidence: obsConfidence } = calculateObservationScore(interaction);

    // Get time decay factor
    const decay = calculateDecay(interaction.timestamp);

    // Update confidence belief
    const currentConfidence = currentState.confidence || 0.5;
    updates.confidence = updateBelief(
        currentConfidence,
        obsScore,
        obsConfidence,
        BASE_LEARNING_RATE,
        decay
    );

    // Update intent beliefs based on task choice pattern
    if (interaction.task) {
        const intentUpdates = estimateIntentFromTask(interaction.task, interaction.timeOfDay);
        updates.intent = {};

        for (const [intentType, observed] of Object.entries(intentUpdates)) {
            const current = currentState.intent[intentType] || 0.33;
            updates.intent[intentType] = updateBelief(
                current,
                observed,
                0.6,  // Medium confidence in intent inference
                BASE_LEARNING_RATE,
                decay
            );
        }

        // Normalize intent probabilities to sum to 1
        const intentSum = Object.values(updates.intent).reduce((a, b) => a + b, 0);
        for (const key in updates.intent) {
            updates.intent[key] = updates.intent[key] / intentSum;
        }
    }

    // Update preference beliefs
    if (interaction.task) {
        const prefUpdates = estimatePreferenceFromTask(interaction.task, interaction.duration);
        updates.preference = {};

        for (const [prefType, observed] of Object.entries(prefUpdates)) {
            const current = currentState.preference[prefType] || 0.5;
            updates.preference[prefType] = updateBelief(
                current,
                observed,
                0.5,  // Medium confidence in preference inference
                BASE_LEARNING_RATE,
                decay
            );
        }
    }

    return { updates, observedScore: obsScore, confidence: obsConfidence };
}

/**
 * Estimate intent from task selection and time
 */
function estimateIntentFromTask(task, timeOfDay) {
    // Simple heuristic: certain tasks suggest certain intents
    // This would be refined based on actual task taxonomy

    const hour = timeOfDay ? new Date(timeOfDay).getHours() : 12;

    // Morning = more deciding, Evening = more exploring
    if (hour >= 6 && hour < 12) {
        return { exploring: 0.3, deciding: 0.6, idle: 0.1 };
    } else if (hour >= 18) {
        return { exploring: 0.6, deciding: 0.2, idle: 0.2 };
    }

    return { exploring: 0.5, deciding: 0.4, idle: 0.1 };
}

/**
 * Estimate preference from task type and engagement
 */
function estimatePreferenceFromTask(task, duration) {
    // Simple heuristic based on task name
    // TODO: Expand with actual task metadata

    const taskLower = task.toLowerCase();

    if (taskLower.includes('video') || taskLower.includes('visual') || taskLower.includes('diagram')) {
        return { visual: 0.8, textBased: 0.2 };
    } else if (taskLower.includes('read') || taskLower.includes('article') || taskLower.includes('notes')) {
        return { visual: 0.2, textBased: 0.8 };
    }

    // Default: neutral
    return { visual: 0.5, textBased: 0.5 };
}

module.exports = {
    updateBelief,
    calculateObservationScore,
    calculateMovingAverage,
    estimateBeliefConfidence,
    updateInternalStates,
    BASE_LEARNING_RATE
};
