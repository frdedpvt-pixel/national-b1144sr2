const beliefStateManager = require('./beliefState');
const { applyDecayToHistory, weightedAverage } = require('./decay');
const { estimateBeliefConfidence } = require('./updateLogic');
const fs = require('fs').promises;
const path = require('path');

const DATA_FILE = path.join(__dirname, '../data/data.json');

/**
 * DECISION LOGIC MODULE
 * Scores and ranks possible actions based on belief state and history
 * Provides explanations for decisions
 */

// Available study tasks (hardcoded for demo)
const AVAILABLE_TASKS = [
    { id: 1, name: 'JavaScript Fundamentals', type: 'textBased', difficulty: 0.3 },
    { id: 2, name: 'React Components Video', type: 'visual', difficulty: 0.5 },
    { id: 3, name: 'Data Structures Practice', type: 'textBased', difficulty: 0.7 },
    { id: 4, name: 'CSS Animations Tutorial', type: 'visual', difficulty: 0.4 },
    { id: 5, name: 'Algorithm Challenges', type: 'textBased', difficulty: 0.9 },
    { id: 6, name: 'UI Design Principles Video', type: 'visual', difficulty: 0.35 },
    { id: 7, name: 'Node.js Backend Guide', type: 'textBased', difficulty: 0.6 },
    { id: 8, name: 'Database Design Diagrams', type: 'visual', difficulty: 0.65 }
];

/**
 * Main decision function: score and rank recommendations
 * Returns top recommendation with explanation
 */
async function getNextRecommendation() {
    // Load current state
    const beliefState = await beliefStateManager.getCurrentState();
    const history = await getInteractionHistory();

    // Score each available task
    const scoredTasks = AVAILABLE_TASKS.map(task => {
        const { score, explanation } = scoreTask(task, beliefState, history);
        return { task, score, explanation };
    });

    // Sort by score (descending)
    scoredTasks.sort((a, b) => b.score - a.score);

    // Get top recommendation
    const topRecommendation = scoredTasks[0];

    // Calculate overall confidence
    const overallConfidence = estimateBeliefConfidence(history);

    // Generate detailed explanation
    const detailedExplanation = generateExplanation(
        topRecommendation,
        beliefState,
        history,
        overallConfidence
    );

    return {
        task: topRecommendation.task,
        score: topRecommendation.score,
        confidence: overallConfidence,
        explanation: detailedExplanation,
        alternativeTasks: scoredTasks.slice(1, 4).map(st => ({
            task: st.task,
            score: st.score
        }))
    };
}

/**
 * Score a single task based on multiple criteria
 * Returns score (0-1) and reasoning
 */
function scoreTask(task, beliefState, history) {
    const scores = [];
    const reasons = [];

    // CRITERION 1: Belief state match (30%)
    const stateMatchScore = calculateStateMatch(task, beliefState);
    scores.push({ value: stateMatchScore, weight: 0.30 });
    reasons.push(`State match: ${(stateMatchScore * 100).toFixed(0)}%`);

    // CRITERION 2: Historical success rate (30%)
    const historyScore = calculateHistoricalSuccess(task, history);
    scores.push({ value: historyScore, weight: 0.30 });
    reasons.push(`Historical success: ${(historyScore * 100).toFixed(0)}%`);

    // CRITERION 3: Time-decayed performance (20%)
    const decayedScore = calculateDecayedPerformance(task, history);
    scores.push({ value: decayedScore, weight: 0.20 });
    reasons.push(`Recent performance: ${(decayedScore * 100).toFixed(0)}%`);

    // CRITERION 4: Exploration bonus (20%)
    const explorationScore = calculateExplorationBonus(task, history);
    scores.push({ value: explorationScore, weight: 0.20 });
    reasons.push(`Exploration value: ${(explorationScore * 100).toFixed(0)}%`);

    // Weighted sum
    const finalScore = scores.reduce((sum, s) => sum + (s.value * s.weight), 0);

    return {
        score: finalScore,
        explanation: reasons.join(', ')
    };
}

/**
 * Calculate how well task matches current belief state
 */
function calculateStateMatch(task, beliefState) {
    let matchScore = 0.5;  // Default

    // Match task difficulty with user confidence
    const confidenceLevel = beliefState.confidence;
    const difficultyGap = Math.abs(task.difficulty - confidenceLevel);
    const difficultyMatch = 1 - difficultyGap;
    matchScore += difficultyMatch * 0.4;

    // Match task type with preference
    const prefMatch = task.type === 'visual'
        ? beliefState.preference.visual
        : beliefState.preference.textBased;
    matchScore += prefMatch * 0.4;

    // Match with intent
    const intentMatch = beliefState.intent.deciding || 0.5;
    matchScore += intentMatch * 0.2;

    return Math.max(0, Math.min(1, matchScore / 1.5));
}

/**
 * Calculate historical success rate for similar tasks
 */
function calculateHistoricalSuccess(task, history) {
    if (history.length === 0) return 0.5;  // Neutral with no data

    // Filter for similar tasks
    const similarInteractions = history.filter(i =>
        i.task && (
            i.task === task.name ||
            i.task.toLowerCase().includes(task.type) ||
            task.name.toLowerCase().includes(i.task.toLowerCase().split(' ')[0])
        )
    );

    if (similarInteractions.length === 0) return 0.5;

    // Calculate success rate (completion + positive feedback)
    const successes = similarInteractions.filter(i =>
        i.completed || (i.feedback && i.feedback !== 'hard')
    ).length;

    return successes / similarInteractions.length;
}

/**
 * Calculate time-decayed performance
 */
function calculateDecayedPerformance(task, history) {
    if (history.length === 0) return 0.5;

    const decayedHistory = applyDecayToHistory(history);

    // Weight recent successes more heavily
    const recentSuccesses = decayedHistory
        .filter(i => i.completed || (i.feedback && i.feedback !== 'hard'))
        .reduce((sum, i) => sum + i.decayWeight, 0);

    const totalWeight = decayedHistory.reduce((sum, i) => sum + i.decayWeight, 0);

    return totalWeight > 0 ? recentSuccesses / totalWeight : 0.5;
}

/**
 * Calculate exploration bonus for underrepresented tasks
 */
function calculateExplorationBonus(task, history) {
    if (history.length < 3) return 0.8;  // Encourage exploration early

    // Count how many times this task has been attempted
    const attemptCount = history.filter(i =>
        i.task === task.name
    ).length;

    // Bonus for untried tasks
    if (attemptCount === 0) return 0.9;

    // Decreasing bonus for repeated tasks
    const bonus = Math.max(0.3, 1 - (attemptCount * 0.15));

    return bonus;
}

/**
 * Generate detailed explanation of decision
 */
function generateExplanation(recommendation, beliefState, history, confidence) {
    const { task, score } = recommendation;

    const explanation = {
        decision: `Recommended: ${task.name}`,
        score: score,
        confidence: confidence,
        confidenceLevel: confidence < 0.3 ? 'Low' : confidence < 0.7 ? 'Medium' : 'High',

        inputsUsed: {
            interactionCount: history.length,
            recentInteractions: Math.min(history.length, 5),
            beliefState: {
                confidence: beliefState.confidence,
                dominantIntent: getDominantKey(beliefState.intent),
                dominantPreference: getDominantKey(beliefState.preference)
            }
        },

        estimatedStates: {
            userConfidence: `${(beliefState.confidence * 100).toFixed(0)}% (${beliefState.confidence < 0.3 ? 'Low' : beliefState.confidence < 0.7 ? 'Medium' : 'High'})`,
            intent: formatBeliefDistribution(beliefState.intent),
            preference: formatBeliefDistribution(beliefState.preference)
        },

        reasoning: {
            why: `Task difficulty (${(task.difficulty * 100).toFixed(0)}%) aligns with your confidence level. ${task.type === 'visual' ? 'Visual' : 'Text-based'
                } format matches your preference tendency.`,
            criteria: recommendation.explanation,
            uncertainties: []
        },

        warnings: []
    };

    // Add uncertainty flags
    if (confidence < 0.3) {
        explanation.warnings.push('⚠️ Low confidence: Limited interaction data available');
        explanation.reasoning.uncertainties.push('Not enough data to confidently predict preferences');
    }

    if (history.length === 0) {
        explanation.warnings.push('⚠️ Cold start: This is an initial guess based on defaults');
        explanation.reasoning.uncertainties.push('No historical data - using default assumptions');
    }

    if (score < 0.4) {
        explanation.warnings.push('⚠️ Low score: No tasks strongly match current state');
        explanation.reasoning.uncertainties.push('Current task options may not be ideal');
    }

    return explanation;
}

/**
 * Helper: get key with highest value
 */
function getDominantKey(obj) {
    return Object.keys(obj).reduce((a, b) => obj[a] > obj[b] ? a : b);
}

/**
 * Helper: format belief distribution
 */
function formatBeliefDistribution(dist) {
    return Object.entries(dist)
        .map(([key, val]) => `${key}: ${(val * 100).toFixed(0)}%`)
        .join(', ');
}

/**
 * Get interaction history from storage
 */
async function getInteractionHistory() {
    try {
        const data = await fs.readFile(DATA_FILE, 'utf8');
        const parsed = JSON.parse(data);
        return parsed.interactionHistory || [];
    } catch (error) {
        console.error('Error loading history:', error);
        return [];
    }
}

/**
 * Record recommendation outcome (accepted/rejected)
 */
async function recordRecommendationOutcome(taskId, accepted) {
    try {
        const data = await fs.readFile(DATA_FILE, 'utf8');
        const parsed = JSON.parse(data);

        // Update metrics
        const metrics = parsed.learningMetrics;
        const totalRecs = (metrics.totalRecommendations || 0) + 1;
        const totalAccepted = (metrics.totalAccepted || 0) + (accepted ? 1 : 0);

        metrics.totalRecommendations = totalRecs;
        metrics.totalAccepted = totalAccepted;
        metrics.recommendationAcceptanceRate = totalAccepted / totalRecs;
        metrics.lastUpdated = new Date().toISOString();

        parsed.learningMetrics = metrics;
        await fs.writeFile(DATA_FILE, JSON.stringify(parsed, null, 2));

        return metrics;
    } catch (error) {
        console.error('Error recording outcome:', error);
        throw error;
    }
}

module.exports = {
    getNextRecommendation,
    scoreTask,
    recordRecommendationOutcome,
    AVAILABLE_TASKS
};
