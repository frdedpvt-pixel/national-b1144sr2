const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

/**
 * ADAPTIVE STUDY ASSISTANT - BACKEND SERVER
 * 
 * Core decision engine implementing:
 * - Belief state estimation
 * - Online learning with exact update formula
 * - Time-based decay
 * - Adaptive recommendations
 * - Graceful handling of partial/missing data
 */

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Request logging
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
    next();
});

// Import routes
const interactionRoutes = require('./routes/interaction');
const recommendationRoutes = require('./routes/recommendation');
const stateRoutes = require('./routes/state');

// Mount routes
app.use('/api/interaction', interactionRoutes);
app.use('/api/recommendation', recommendationRoutes);
app.use('/api/state', stateRoutes);

// Health check
app.get('/health', (req, res) => {
    res.json({
        status: 'healthy',
        message: 'Adaptive Study Assistant Backend is running',
        timestamp: new Date().toISOString()
    });
});

// Root endpoint
app.get('/', (req, res) => {
    res.json({
        name: 'Adaptive Study Assistant API',
        version: '1.0.0',
        description: 'Decision engine with online learning under partial information',
        endpoints: {
            interaction: {
                'POST /api/interaction/record': 'Record user interaction',
                'GET /api/interaction/history': 'Get interaction history',
                'DELETE /api/interaction/reset': 'Reset all data'
            },
            recommendation: {
                'GET /api/recommendation/next': 'Get next recommended task',
                'POST /api/recommendation/feedback': 'Record recommendation outcome'
            },
            state: {
                'GET /api/state/current': 'Get current belief state',
                'GET /api/state/explanation': 'Get detailed explanation',
                'GET /api/state/metrics': 'Get learning metrics'
            }
        }
    });
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error('Server error:', err);
    res.status(500).json({
        success: false,
        error: err.message,
        message: 'Internal server error - system continues with degraded functionality'
    });
});

// 404 handler
app.use((req, res) => {
    res.status(404).json({
        success: false,
        error: 'Endpoint not found',
        available: [
            '/api/interaction/record',
            '/api/interaction/history',
            '/api/recommendation/next',
            '/api/recommendation/feedback',
            '/api/state/current',
            '/api/state/explanation',
            '/api/state/metrics'
        ]
    });
});

// Start server
app.listen(PORT, () => {
    console.log('='.repeat(60));
    console.log('🧠 Adaptive Study Assistant Backend');
    console.log('='.repeat(60));
    console.log(`Server running on port ${PORT}`);
    console.log(`Health check: http://localhost:${PORT}/health`);
    console.log(`API docs: http://localhost:${PORT}/`);
    console.log('='.repeat(60));
    console.log('Decision engine features:');
    console.log('  ✓ Belief state estimation');
    console.log('  ✓ Online learning (no training phase)');
    console.log('  ✓ Time-based decay');
    console.log('  ✓ Partial data handling');
    console.log('  ✓ Decision explanations');
    console.log('='.repeat(60));
});

module.exports = app;
