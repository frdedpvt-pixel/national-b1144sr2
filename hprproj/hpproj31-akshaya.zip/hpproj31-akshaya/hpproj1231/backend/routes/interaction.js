const express = require('express');
const router = express.Router();
const fs = require('fs').promises;
const path = require('path');
const beliefStateManager = require('../engine/beliefState');
const { updateInternalStates } = require('../engine/updateLogic');

const DATA_FILE = path.join(__dirname, '../data/data.json');

/**
 * INTERACTION ROUTES
 * Handle recording and retrieving user interactions
 */

/**
 * POST /api/interaction/record
 * Record a new user interaction
 * 
 * Body (all fields optional):
 * - timeOfDay: timestamp
 * - task: string
 * - duration: number (seconds)
 * - completed: boolean
 * - feedback: 'easy' | 'okay' | 'hard'
 */
router.post('/record', async (req, res) => {
    try {
        const interaction = {
            timestamp: req.body.timeOfDay || new Date().toISOString(),
            task: req.body.task || null,
            duration: req.body.duration || null,
            completed: req.body.completed !== undefined ? req.body.completed : null,
            feedback: req.body.feedback || null,
            timeOfDay: req.body.timeOfDay || new Date().toISOString()
        };

        // Load current state and history
        const currentState = await beliefStateManager.getCurrentState();
        const data = await fs.readFile(DATA_FILE, 'utf8');
        const parsed = JSON.parse(data);
        const history = parsed.interactionHistory || [];

        // Update internal states using the decision engine
        const { updates, observedScore, confidence } = updateInternalStates(
            currentState,
            interaction,
            history
        );

        // Store observed score and confidence with interaction
        interaction.observedScore = observedScore;
        interaction.observationConfidence = confidence;

        // Update belief state
        const newState = await beliefStateManager.updateState(updates);

        // Add interaction to history
        history.push(interaction);
        parsed.interactionHistory = history;

        // Update metrics
        parsed.learningMetrics.totalInteractions = history.length;
        parsed.learningMetrics.averageConfidence = updates.confidence || newState.confidence;
        parsed.learningMetrics.lastUpdated = new Date().toISOString();

        // Persist
        await fs.writeFile(DATA_FILE, JSON.stringify(parsed, null, 2));

        res.json({
            success: true,
            interaction,
            updatedState: newState,
            message: 'Interaction recorded and belief state updated'
        });

    } catch (error) {
        console.error('Error recording interaction:', error);
        res.status(500).json({
            success: false,
            error: error.message,
            message: 'Failed to record interaction gracefully - system continues'
        });
    }
});

/**
 * GET /api/interaction/history
 * Get all interaction history
 */
router.get('/history', async (req, res) => {
    try {
        const data = await fs.readFile(DATA_FILE, 'utf8');
        const parsed = JSON.parse(data);
        const history = parsed.interactionHistory || [];

        res.json({
            success: true,
            history,
            count: history.length
        });

    } catch (error) {
        console.error('Error loading history:', error);
        res.status(500).json({
            success: false,
            error: error.message,
            history: []
        });
    }
});

/**
 * DELETE /api/interaction/reset
 * Reset all data (for testing)
 */
router.delete('/reset', async (req, res) => {
    try {
        const defaultData = {
            beliefState: {
                confidence: 0.5,
                intent: {
                    exploring: 0.6,
                    deciding: 0.3,
                    idle: 0.1
                },
                preference: {
                    visual: 0.5,
                    textBased: 0.5
                }
            },
            interactionHistory: [],
            learningMetrics: {
                totalInteractions: 0,
                recommendationAcceptanceRate: 0,
                averageConfidence: 0.5,
                lastUpdated: null
            }
        };

        await fs.writeFile(DATA_FILE, JSON.stringify(defaultData, null, 2));
        beliefStateManager.state = null;  // Force reload

        res.json({
            success: true,
            message: 'All data reset to defaults'
        });

    } catch (error) {
        console.error('Error resetting data:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

module.exports = router;
