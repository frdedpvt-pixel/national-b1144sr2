const express = require('express');
const router = express.Router();
const { getNextRecommendation, recordRecommendationOutcome } = require('../engine/decisionLogic');

/**
 * RECOMMENDATION ROUTES
 * Handle getting recommendations and recording outcomes
 */

/**
 * GET /api/recommendation/next
 * Get next recommended task based on current belief state
 */
router.get('/next', async (req, res) => {
    try {
        const recommendation = await getNextRecommendation();

        res.json({
            success: true,
            recommendation
        });

    } catch (error) {
        console.error('Error getting recommendation:', error);
        res.status(500).json({
            success: false,
            error: error.message,
            message: 'Failed to generate recommendation - insufficient data or system error'
        });
    }
});

/**
 * POST /api/recommendation/feedback
 * Record whether user accepted or rejected recommendation
 * 
 * Body:
 * - taskId: number
 * - accepted: boolean
 */
router.post('/feedback', async (req, res) => {
    try {
        const { taskId, accepted } = req.body;

        if (taskId === undefined || accepted === undefined) {
            return res.status(400).json({
                success: false,
                error: 'Missing required fields: taskId, accepted'
            });
        }

        const metrics = await recordRecommendationOutcome(taskId, accepted);

        res.json({
            success: true,
            metrics,
            message: `Recommendation ${accepted ? 'accepted' : 'rejected'} - learning metrics updated`
        });

    } catch (error) {
        console.error('Error recording feedback:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

module.exports = router;
