const express = require('express');
const router = express.Router();
const beliefStateManager = require('../engine/beliefState');
const fs = require('fs').promises;
const path = require('path');

const DATA_FILE = path.join(__dirname, '../data/data.json');

/**
 * STATE ROUTES
 * Handle getting current state and explanations
 */

/**
 * GET /api/state/current
 * Get current belief state
 */
router.get('/current', async (req, res) => {
    try {
        const state = await beliefStateManager.getCurrentState();

        res.json({
            success: true,
            state,
            interpretation: {
                confidenceLevel: beliefStateManager.getConfidenceLevel(),
                dominantIntent: beliefStateManager.getDominantIntent(),
                dominantPreference: beliefStateManager.getDominantPreference()
            }
        });

    } catch (error) {
        console.error('Error getting state:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * GET /api/state/explanation
 * Get detailed explanation of current state and last decision
 */
router.get('/explanation', async (req, res) => {
    try {
        const state = await beliefStateManager.getCurrentState();
        const data = await fs.readFile(DATA_FILE, 'utf8');
        const parsed = JSON.parse(data);
        const history = parsed.interactionHistory || [];

        // Get last few interactions for context
        const recentHistory = history.slice(-5);

        const explanation = {
            currentBeliefState: state,
            dataQuality: {
                totalInteractions: history.length,
                dataPoints: recentHistory.length,
                confidenceLevel: beliefStateManager.getConfidenceLevel()
            },
            stateInterpretation: {
                confidence: `${(state.confidence * 100).toFixed(0)}% - User is ${state.confidence < 0.3 ? 'struggling' :
                        state.confidence < 0.7 ? 'progressing' : 'excelling'
                    }`,
                intent: formatDistribution(state.intent),
                preference: formatDistribution(state.preference)
            },
            recentInteractions: recentHistory.map(i => ({
                task: i.task,
                completed: i.completed,
                feedback: i.feedback,
                observedScore: i.observedScore,
                timestamp: i.timestamp
            })),
            uncertainties: [],
            warnings: []
        };

        // Add uncertainty flags
        if (history.length === 0) {
            explanation.uncertainties.push('No interaction data - using default assumptions');
            explanation.warnings.push('⚠️ Cold start mode');
        }

        if (history.length < 5) {
            explanation.uncertainties.push('Limited data - beliefs may be inaccurate');
            explanation.warnings.push('⚠️ Low data confidence');
        }

        if (state.confidence < 0.3) {
            explanation.warnings.push('⚠️ Low user confidence detected - consider easier tasks');
        }

        res.json({
            success: true,
            explanation
        });

    } catch (error) {
        console.error('Error getting explanation:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * GET /api/state/metrics
 * Get learning metrics over time
 */
router.get('/metrics', async (req, res) => {
    try {
        const data = await fs.readFile(DATA_FILE, 'utf8');
        const parsed = JSON.parse(data);
        const metrics = parsed.learningMetrics;
        const history = parsed.interactionHistory || [];

        // Calculate additional metrics
        const completionRate = history.length > 0
            ? history.filter(i => i.completed).length / history.length
            : 0;

        const recentHistory = history.slice(-10);
        const recentCompletionRate = recentHistory.length > 0
            ? recentHistory.filter(i => i.completed).length / recentHistory.length
            : 0;

        // Trend analysis
        const trend = recentCompletionRate > completionRate ? 'improving' :
            recentCompletionRate < completionRate ? 'declining' : 'stable';

        res.json({
            success: true,
            metrics: {
                ...metrics,
                completionRate,
                recentCompletionRate,
                trend,
                interactionCount: history.length
            }
        });

    } catch (error) {
        console.error('Error getting metrics:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * Helper: format distribution as readable string
 */
function formatDistribution(dist) {
    const entries = Object.entries(dist)
        .sort(([, a], [, b]) => b - a)
        .map(([key, val]) => `${key} (${(val * 100).toFixed(0)}%)`);
    return entries.join(', ');
}

module.exports = router;
