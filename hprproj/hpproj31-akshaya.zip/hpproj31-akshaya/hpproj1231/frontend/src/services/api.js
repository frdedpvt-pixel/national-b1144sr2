/**
 * API SERVICE
 * Client for interacting with backend API
 * Handles offline scenarios gracefully
 */

const API_BASE = 'http://localhost:5000/api';

class ApiService {
    constructor() {
        this.isOnline = true;
        this.cache = {};
    }

    /**
     * Generic fetch wrapper with error handling
     */
    async request(endpoint, options = {}) {
        try {
            const response = await fetch(`${API_BASE}${endpoint}`, {
                headers: {
                    'Content-Type': 'application/json',
                    ...options.headers
                },
                ...options
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const data = await response.json();
            this.isOnline = true;
            return data;

        } catch (error) {
            console.error('API Error:', error);
            this.isOnline = false;

            // Return cached data if offline
            if (this.cache[endpoint]) {
                console.warn('Using cached data (offline mode)');
                return this.cache[endpoint];
            }

            throw error;
        }
    }

    /**
     * Record user interaction
     */
    async recordInteraction(interaction) {
        return this.request('/interaction/record', {
            method: 'POST',
            body: JSON.stringify(interaction)
        });
    }

    /**
     * Get interaction history
     */
    async getHistory() {
        const data = await this.request('/interaction/history');
        this.cache['/interaction/history'] = data;
        return data;
    }

    /**
     * Get next recommendation
     */
    async getRecommendation() {
        const data = await this.request('/recommendation/next');
        this.cache['/recommendation/next'] = data;
        return data;
    }

    /**
     * Record recommendation feedback
     */
    async recordFeedback(taskId, accepted) {
        return this.request('/recommendation/feedback', {
            method: 'POST',
            body: JSON.stringify({ taskId, accepted })
        });
    }

    /**
     * Get current belief state
     */
    async getCurrentState() {
        const data = await this.request('/state/current');
        this.cache['/state/current'] = data;
        return data;
    }

    /**
     * Get detailed explanation
     */
    async getExplanation() {
        const data = await this.request('/state/explanation');
        this.cache['/state/explanation'] = data;
        return data;
    }

    /**
     * Get learning metrics
     */
    async getMetrics() {
        const data = await this.request('/state/metrics');
        this.cache['/state/metrics'] = data;
        return data;
    }

    /**
     * Reset all data (for testing)
     */
    async resetData() {
        return this.request('/interaction/reset', {
            method: 'DELETE'
        });
    }

    /**
     * Check if online
     */
    getStatus() {
        return {
            online: this.isOnline,
            message: this.isOnline ? 'Connected' : 'Offline - using cached data'
        };
    }
}

export default new ApiService();
