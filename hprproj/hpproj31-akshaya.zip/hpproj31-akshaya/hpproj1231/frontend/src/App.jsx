import React, { useState } from 'react';
import UserInteraction from './components/UserInteraction';
import RecommendationOutput from './components/RecommendationOutput';
import ExplanationPanel from './components/ExplanationPanel';
import LearningHistory from './components/LearningHistory';
import api from './services/api';

/**
 * ADAPTIVE STUDY ASSISTANT
 * Main application component with tabbed navigation
 */

function App() {
    const [activeTab, setActiveTab] = useState('interaction');
    const [status, setStatus] = useState({ online: true });

    // Check connection status
    React.useEffect(() => {
        const checkStatus = () => {
            const apiStatus = api.getStatus();
            setStatus(apiStatus);
        };

        checkStatus();
        const interval = setInterval(checkStatus, 5000);
        return () => clearInterval(interval);
    }, []);

    const handleReset = async () => {
        if (!confirm('Are you sure you want to reset all data? This cannot be undone.')) {
            return;
        }

        try {
            await api.resetData();
            alert('Data reset successfully! Refresh the page to see changes.');
            window.location.reload();
        } catch (error) {
            alert('Error resetting data: ' + error.message);
        }
    };

    return (
        <div className="container">
            <header className="text-center mb-3">
                <h1>🧠 Adaptive Study Assistant</h1>
                <p style={{ fontSize: '1.1rem', opacity: 0.9 }}>
                    Decision Engine with Online Learning Under Partial Information
                </p>
                <div className="flex align-center justify-between mt-2">
                    <div className={`badge ${status.online ? 'badge-success' : 'badge-danger'}`}>
                        {status.online ? '🟢 Online' : '🔴 Offline'}
                    </div>
                    <button className="danger" onClick={handleReset} style={{ fontSize: '0.9rem' }}>
                        🗑️ Reset All Data
                    </button>
                </div>
            </header>

            <nav className="nav-tabs">
                <button
                    className={`nav-tab ${activeTab === 'interaction' ? 'active' : ''}`}
                    onClick={() => setActiveTab('interaction')}
                >
                    📝 Interact
                </button>
                <button
                    className={`nav-tab ${activeTab === 'recommendation' ? 'active' : ''}`}
                    onClick={() => setActiveTab('recommendation')}
                >
                    🎯 Recommendations
                </button>
                <button
                    className={`nav-tab ${activeTab === 'explanation' ? 'active' : ''}`}
                    onClick={() => setActiveTab('explanation')}
                >
                    🔍 Explanation
                </button>
                <button
                    className={`nav-tab ${activeTab === 'history' ? 'active' : ''}`}
                    onClick={() => setActiveTab('history')}
                >
                    📈 Learning
                </button>
            </nav>

            <main>
                {activeTab === 'interaction' && <UserInteraction />}
                {activeTab === 'recommendation' && <RecommendationOutput />}
                {activeTab === 'explanation' && <ExplanationPanel />}
                {activeTab === 'history' && <LearningHistory />}
            </main>

            <footer className="text-center mt-3" style={{ opacity: 0.7, fontSize: '0.9rem' }}>
                <p>
                    System Features: Belief State Estimation • Online Learning • Time Decay •
                    Partial Data Handling • Decision Explanations • Failure Awareness
                </p>
                <p style={{ marginTop: '0.5rem' }}>
                    No deep learning • No training phase • All learning is online
                </p>
            </footer>
        </div>
    );
}

export default App;
