import React, { useState, useEffect } from 'react';
import api from '../services/api';

/**
 * RECOMMENDATION OUTPUT COMPONENT
 * Displays AI-recommended next task
 * Shows score, confidence, and brief reasoning
 */

function RecommendationOutput() {
    const [recommendation, setRecommendation] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    const loadRecommendation = async () => {
        setLoading(true);
        setError(null);

        try {
            const result = await api.getRecommendation();
            setRecommendation(result.recommendation);
        } catch (err) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    const handleAccept = async () => {
        if (!recommendation) return;

        try {
            await api.recordFeedback(recommendation.task.id, true);
            await loadRecommendation(); // Get next recommendation
        } catch (err) {
            console.error('Error recording feedback:', err);
        }
    };

    const handleReject = async () => {
        if (!recommendation) return;

        try {
            await api.recordFeedback(recommendation.task.id, false);
            await loadRecommendation(); // Get next recommendation
        } catch (err) {
            console.error('Error recording feedback:', err);
        }
    };

    useEffect(() => {
        loadRecommendation();
    }, []);

    if (loading) {
        return (
            <div className="card">
                <h2>🎯 Recommended Task</h2>
                <div className="spinner"></div>
            </div>
        );
    }

    if (error) {
        return (
            <div className="card">
                <h2>🎯 Recommended Task</h2>
                <div className="error">
                    <strong>Error:</strong> {error}
                    <br />
                    <button className="primary mt-2" onClick={loadRecommendation}>
                        Try Again
                    </button>
                </div>
            </div>
        );
    }

    if (!recommendation) {
        return (
            <div className="card">
                <h2>🎯 Recommended Task</h2>
                <p>No recommendation available</p>
            </div>
        );
    }

    const { task, score, confidence, explanation } = recommendation;

    return (
        <div className="card">
            <h2>🎯 Recommended Task</h2>

            <div className="card-dark mb-2" style={{ padding: '1.5rem' }}>
                <h3>{task.name}</h3>
                <div className="flex align-center mb-2">
                    <span className="badge badge-info">
                        Type: {task.type === 'visual' ? '👁️ Visual' : '📝 Text'}
                    </span>
                    <span className="badge badge-warning">
                        Difficulty: {(task.difficulty * 100).toFixed(0)}%
                    </span>
                </div>

                <div className="mb-2">
                    <strong>Match Score:</strong> {(score * 100).toFixed(1)}%
                </div>

                <div className="mb-2">
                    <strong>System Confidence:</strong>{' '}
                    <span className={`badge ${confidence < 0.3 ? 'badge-danger' :
                            confidence < 0.7 ? 'badge-warning' :
                                'badge-success'
                        }`}>
                        {(confidence * 100).toFixed(0)}% ({explanation.confidenceLevel})
                    </span>
                </div>

                <div className="mb-2">
                    <strong>Why this task?</strong>
                    <p className="opacity-70 mt-1">{explanation.reasoning.why}</p>
                </div>

                {explanation.warnings && explanation.warnings.length > 0 && (
                    <div className="warning">
                        {explanation.warnings.map((w, i) => (
                            <div key={i}>{w}</div>
                        ))}
                    </div>
                )}
            </div>

            <div className="flex">
                <button className="success" onClick={handleAccept}>
                    ✓ Accept Recommendation
                </button>
                <button className="danger" onClick={handleReject}>
                    ✗ Skip This Task
                </button>
                <button className="secondary" onClick={loadRecommendation}>
                    🔄 Refresh
                </button>
            </div>

            {recommendation.alternativeTasks && (
                <div className="mt-2">
                    <h4 className="mb-1">Alternative Suggestions:</h4>
                    <div style={{ fontSize: '0.9rem', opacity: 0.8 }}>
                        {recommendation.alternativeTasks.map((alt, i) => (
                            <div key={i}>
                                {i + 1}. {alt.task.name} (Score: {(alt.score * 100).toFixed(0)}%)
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}

export default RecommendationOutput;
