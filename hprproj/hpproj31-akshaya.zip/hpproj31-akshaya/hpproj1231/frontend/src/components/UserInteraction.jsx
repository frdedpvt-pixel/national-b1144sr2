import React, { useState } from 'react';
import api from '../services/api';

/**
 * USER INTERACTION COMPONENT
 * Allows users to record study sessions with optional data
 * Handles partial input gracefully
 */

const TASKS = ['JavaScript Fundamentals', 'React Components Video', 'Data Structures Practice',
    'CSS Animations Tutorial', 'Algorithm Challenges', 'UI Design Principles Video',
    'Node.js Backend Guide', 'Database Design Diagrams'];

function UserInteraction() {
    const [task, setTask] = useState('');
    const [duration, setDuration] = useState('');
    const [completed, setCompleted] = useState(null);
    const [feedback, setFeedback] = useState('');
    const [loading, setLoading] = useState(false);
    const [message, setMessage] = useState(null);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setMessage(null);

        try {
            // Build interaction object (only include provided fields)
            const interaction = {
                timeOfDay: new Date().toISOString()
            };

            if (task) interaction.task = task;
            if (duration) interaction.duration = parseInt(duration) * 60; // Convert to seconds
            if (completed !== null) interaction.completed = completed;
            if (feedback) interaction.feedback = feedback;

            const result = await api.recordInteraction(interaction);

            setMessage({
                type: 'success',
                text: 'Interaction recorded! Belief state updated.'
            });

            // Reset form
            setTask('');
            setDuration('');
            setCompleted(null);
            setFeedback('');

        } catch (error) {
            setMessage({
                type: 'error',
                text: `Error: ${error.message} - System continues with available data`
            });
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="card">
            <h2>📝 Record Study Session</h2>
            <p className="opacity-70 mb-2">
                All fields are optional - the system works with partial information
            </p>

            {message && (
                <div className={message.type === 'success' ? 'success' : 'error'}>
                    {message.text}
                </div>
            )}

            <form onSubmit={handleSubmit}>
                <div className="mb-2">
                    <label style={{ display: 'block', marginBottom: '0.5rem' }}>
                        What did you study? (optional)
                    </label>
                    <select
                        value={task}
                        onChange={(e) => setTask(e.target.value)}
                    >
                        <option value="">-- Select a task --</option>
                        {TASKS.map((t, i) => (
                            <option key={i} value={t}>{t}</option>
                        ))}
                    </select>
                </div>

                <div className="mb-2">
                    <label style={{ display: 'block', marginBottom: '0.5rem' }}>
                        How long did you study? (minutes, optional)
                    </label>
                    <input
                        type="number"
                        value={duration}
                        onChange={(e) => setDuration(e.target.value)}
                        placeholder="e.g., 30"
                        min="0"
                    />
                </div>

                <div className="mb-2">
                    <label style={{ display: 'block', marginBottom: '0.5rem' }}>
                        Did you complete the task? (optional)
                    </label>
                    <div className="flex">
                        <button
                            type="button"
                            className={completed === true ? 'success' : 'secondary'}
                            onClick={() => setCompleted(true)}
                        >
                            ✓ Yes
                        </button>
                        <button
                            type="button"
                            className={completed === false ? 'danger' : 'secondary'}
                            onClick={() => setCompleted(false)}
                        >
                            ✗ No
                        </button>
                        <button
                            type="button"
                            className="secondary"
                            onClick={() => setCompleted(null)}
                        >
                            Skip
                        </button>
                    </div>
                </div>

                <div className="mb-2">
                    <label style={{ display: 'block', marginBottom: '0.5rem' }}>
                        How did it feel? (optional)
                    </label>
                    <div className="flex">
                        <button
                            type="button"
                            className={feedback === 'easy' ? 'success' : 'secondary'}
                            onClick={() => setFeedback('easy')}
                        >
                            😊 Easy
                        </button>
                        <button
                            type="button"
                            className={feedback === 'okay' ? 'primary' : 'secondary'}
                            onClick={() => setFeedback('okay')}
                        >
                            😐 Okay
                        </button>
                        <button
                            type="button"
                            className={feedback === 'hard' ? 'danger' : 'secondary'}
                            onClick={() => setFeedback('hard')}
                        >
                            😰 Hard
                        </button>
                        <button
                            type="button"
                            className="secondary"
                            onClick={() => setFeedback('')}
                        >
                            Skip
                        </button>
                    </div>
                </div>

                <button
                    type="submit"
                    className="primary"
                    disabled={loading}
                    style={{ width: '100%', marginTop: '1rem' }}
                >
                    {loading ? 'Recording...' : 'Record Interaction'}
                </button>
            </form>

            <div className="warning mt-2">
                <strong>Note:</strong> Missing data is treated as uncertainty, not failure.
                The system continues learning from whatever information you provide.
            </div>
        </div>
    );
}

export default UserInteraction;
