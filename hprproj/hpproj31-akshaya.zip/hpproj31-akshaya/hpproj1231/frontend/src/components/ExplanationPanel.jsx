import React, { useState, useEffect } from 'react';
import api from '../services/api';

/**
 * EXPLANATION PANEL COMPONENT
 * Shows transparent decision logic
 * Reveals internal states, inputs, uncertainties
 */

function ExplanationPanel() {
    const [explanation, setExplanation] = useState(null);
    const [state, setState] = useState(null);
    const [loading, setLoading] = useState(false);

    const loadExplanation = async () => {
        setLoading(true);

        try {
            const [expResult, stateResult] = await Promise.all([
                api.getExplanation(),
                api.getCurrentState()
            ]);

            setExplanation(expResult.explanation);
            setState(stateResult.state);
        } catch (error) {
            console.error('Error loading explanation:', error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadExplanation();
    }, []);

    if (loading) {
        return (
            <div className="card">
                <h2>🔍 Decision Logic Explanation</h2>
                <div className="spinner"></div>
            </div>
        );
    }

    if (!explanation || !state) {
        return (
            <div className="card">
                <h2>🔍 Decision Logic Explanation</h2>
                <p>No data available. Record some interactions first.</p>
            </div>
        );
    }

    return (
        <div className="card">
            <h2>🔍 Decision Logic Explanation</h2>
            <p className="opacity-70 mb-2">
                Transparent view into how decisions are made
            </p>

            <button className="secondary mb-2" onClick={loadExplanation}>
                🔄 Refresh Explanation
            </button>

            {/* Warnings */}
            {explanation.warnings && explanation.warnings.length > 0 && (
                <div className="warning mb-2">
                    <strong>System Warnings:</strong>
                    {explanation.warnings.map((w, i) => (
                        <div key={i}>{w}</div>
                    ))}
                </div>
            )}

            {/* Inputs Used */}
            <div className="card-dark mb-2">
                <h3>1️⃣ Inputs Used</h3>
                <p><strong>Total Interactions:</strong> {explanation.dataQuality.totalInteractions}</p>
                <p><strong>Recent Data Points:</strong> {explanation.dataQuality.dataPoints}</p>
                <p><strong>Overall Confidence:</strong> {explanation.dataQuality.confidenceLevel}</p>
            </div>

            {/* Estimated States */}
            <div className="card-dark mb-2">
                <h3>2️⃣ Estimated Internal States</h3>
                <p><strong>User Confidence:</strong> {explanation.estimatedStates.userConfidence}</p>
                <p><strong>Intent Distribution:</strong> {explanation.estimatedStates.intent}</p>
                <p><strong>Preference Distribution:</strong> {explanation.estimatedStates.preference}</p>

                <div className="mt-2" style={{ fontSize: '0.9rem', opacity: 0.8 }}>
                    <em>These states are ESTIMATED from behavior, not directly measured</em>
                </div>
            </div>

            {/* Current Belief State (Raw) */}
            <div className="card-dark mb-2">
                <h3>3️⃣ Raw Belief Values</h3>
                <p><strong>Confidence:</strong> {state.confidence.toFixed(4)}</p>
                <p><strong>Intent Beliefs:</strong></p>
                <ul style={{ marginLeft: '1.5rem', fontSize: '0.9rem' }}>
                    <li>Exploring: {(state.intent.exploring * 100).toFixed(1)}%</li>
                    <li>Deciding: {(state.intent.deciding * 100).toFixed(1)}%</li>
                    <li>Idle: {(state.intent.idle * 100).toFixed(1)}%</li>
                </ul>
                <p><strong>Preference Beliefs:</strong></p>
                <ul style={{ marginLeft: '1.5rem', fontSize: '0.9rem' }}>
                    <li>Visual: {(state.preference.visual * 100).toFixed(1)}%</li>
                    <li>Text-based: {(state.preference.textBased * 100).toFixed(1)}%</li>
                </ul>
            </div>

            {/* Recent Interactions */}
            {explanation.recentInteractions && explanation.recentInteractions.length > 0 && (
                <div className="card-dark mb-2">
                    <h3>4️⃣ Recent Interactions</h3>
                    {explanation.recentInteractions.map((interaction, i) => (
                        <div key={i} style={{
                            borderBottom: i < explanation.recentInteractions.length - 1 ? '1px solid rgba(255,255,255,0.1)' : 'none',
                            paddingBottom: '0.5rem',
                            marginBottom: '0.5rem'
                        }}>
                            <div><strong>{interaction.task || 'Unknown task'}</strong></div>
                            <div style={{ fontSize: '0.85rem', opacity: 0.8 }}>
                                Completed: {interaction.completed !== null ? (interaction.completed ? '✓' : '✗') : '?'} |
                                Feedback: {interaction.feedback || 'none'} |
                                Score: {interaction.observedScore ? interaction.observedScore.toFixed(2) : 'N/A'}
                            </div>
                        </div>
                    ))}
                </div>
            )}

            {/* Uncertainties */}
            {explanation.uncertainties && explanation.uncertainties.length > 0 && (
                <div className="warning">
                    <strong>Known Uncertainties:</strong>
                    {explanation.uncertainties.map((u, i) => (
                        <div key={i}>• {u}</div>
                    ))}
                </div>
            )}

            <div className="success mt-2">
                <strong>✓ Honest System:</strong> All uncertainties and limitations are disclosed.
                Decisions reflect actual internal logic, not marketing narratives.
            </div>
        </div>
    );
}

export default ExplanationPanel;
