import React, { useState, useEffect } from 'react';
import api from '../services/api';

/**
 * LEARNING HISTORY COMPONENT
 * Shows system improvement over time
 * Tracks metrics and adaptation
 */

function LearningHistory() {
    const [metrics, setMetrics] = useState(null);
    const [history, setHistory] = useState([]);
    const [loading, setLoading] = useState(false);

    const loadData = async () => {
        setLoading(true);

        try {
            const [metricsResult, historyResult] = await Promise.all([
                api.getMetrics(),
                api.getHistory()
            ]);

            setMetrics(metricsResult.metrics);
            setHistory(historyResult.history || []);
        } catch (error) {
            console.error('Error loading history:', error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadData();
    }, []);

    if (loading) {
        return (
            <div className="card">
                <h2>📈 Learning & Adaptation</h2>
                <div className="spinner"></div>
            </div>
        );
    }

    if (!metrics) {
        return (
            <div className="card">
                <h2>📈 Learning & Adaptation</h2>
                <p>No metrics available yet. Use the system to generate data.</p>
            </div>
        );
    }

    return (
        <div className="card">
            <h2>📈 Learning & Adaptation</h2>
            <p className="opacity-70 mb-2">
                System performance and improvement over time
            </p>

            <button className="secondary mb-2" onClick={loadData}>
                🔄 Refresh Metrics
            </button>

            {/* Key Metrics */}
            <div className="grid grid-2 mb-2">
                <div className="card-dark">
                    <h3>Total Interactions</h3>
                    <div style={{ fontSize: '2rem', fontWeight: 'bold' }}>
                        {metrics.interactionCount}
                    </div>
                </div>

                <div className="card-dark">
                    <h3>Average Confidence</h3>
                    <div style={{ fontSize: '2rem', fontWeight: 'bold' }}>
                        {(metrics.averageConfidence * 100).toFixed(0)}%
                    </div>
                    <span className={`badge ${metrics.averageConfidence < 0.3 ? 'badge-danger' :
                            metrics.averageConfidence < 0.7 ? 'badge-warning' :
                                'badge-success'
                        }`}>
                        {metrics.averageConfidence < 0.3 ? 'Low' :
                            metrics.averageConfidence < 0.7 ? 'Medium' : 'High'}
                    </span>
                </div>

                <div className="card-dark">
                    <h3>Completion Rate</h3>
                    <div style={{ fontSize: '2rem', fontWeight: 'bold' }}>
                        {(metrics.completionRate * 100).toFixed(1)}%
                    </div>
                    <div style={{ fontSize: '0.9rem', opacity: 0.8 }}>
                        Overall task completion
                    </div>
                </div>

                <div className="card-dark">
                    <h3>Recent Performance</h3>
                    <div style={{ fontSize: '2rem', fontWeight: 'bold' }}>
                        {(metrics.recentCompletionRate * 100).toFixed(1)}%
                    </div>
                    <span className={`badge ${metrics.trend === 'improving' ? 'badge-success' :
                            metrics.trend === 'declining' ? 'badge-danger' :
                                'badge-info'
                        }`}>
                        {metrics.trend === 'improving' ? '📈 Improving' :
                            metrics.trend === 'declining' ? '📉 Declining' : '➡️ Stable'}
                    </span>
                </div>
            </div>

            {/* Recommendation Metrics */}
            {metrics.totalRecommendations > 0 && (
                <div className="card-dark mb-2">
                    <h3>Recommendation Performance</h3>
                    <p><strong>Total Recommendations:</strong> {metrics.totalRecommendations}</p>
                    <p><strong>Accepted:</strong> {metrics.totalAccepted}</p>
                    <p><strong>Acceptance Rate:</strong> {(metrics.recommendationAcceptanceRate * 100).toFixed(1)}%</p>
                </div>
            )}

            {/* Learning Progress */}
            <div className="card-dark mb-2">
                <h3>Learning Evidence</h3>
                <p>
                    <strong>Data Points:</strong> {history.length} interactions recorded
                </p>
                <p>
                    <strong>Learning Mode:</strong> Online (updates after each interaction)
                </p>
                <p>
                    <strong>Last Updated:</strong> {metrics.lastUpdated
                        ? new Date(metrics.lastUpdated).toLocaleString()
                        : 'Never'}
                </p>

                {history.length > 5 && (
                    <div className="success mt-2">
                        ✓ System has sufficient data to make informed decisions
                    </div>
                )}

                {history.length <= 5 && history.length > 0 && (
                    <div className="warning mt-2">
                        ⚠️ Limited data - recommendations may not be optimal yet
                    </div>
                )}

                {history.length === 0 && (
                    <div className="warning mt-2">
                        ⚠️ No data yet - system using default assumptions
                    </div>
                )}
            </div>

            {/* Interaction Timeline */}
            {history.length > 0 && (
                <div className="card-dark">
                    <h3>Recent Activity Timeline</h3>
                    <div style={{ maxHeight: '300px', overflowY: 'auto' }}>
                        {history.slice().reverse().slice(0, 10).map((interaction, i) => (
                            <div key={i} style={{
                                borderBottom: i < 9 ? '1px solid rgba(255,255,255,0.1)' : 'none',
                                padding: '0.75rem 0'
                            }}>
                                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                    <div>
                                        <strong>{interaction.task || 'Unknown task'}</strong>
                                        <div style={{ fontSize: '0.85rem', opacity: 0.7 }}>
                                            {new Date(interaction.timestamp).toLocaleString()}
                                        </div>
                                    </div>
                                    <div style={{ display: 'flex', gap: '0.5rem' }}>
                                        {interaction.completed !== null && (
                                            <span className={`badge ${interaction.completed ? 'badge-success' : 'badge-danger'}`}>
                                                {interaction.completed ? '✓ Done' : '✗ Not Done'}
                                            </span>
                                        )}
                                        {interaction.feedback && (
                                            <span className={`badge ${interaction.feedback === 'easy' ? 'badge-success' :
                                                    interaction.feedback === 'hard' ? 'badge-danger' :
                                                        'badge-warning'
                                                }`}>
                                                {interaction.feedback}
                                            </span>
                                        )}
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}

export default LearningHistory;
